'use client'

import { useEffect, useRef, useState } from 'react'
import { type Agent, type Message, type MessageMark, type Status, hats, discussionContext, insertDiscussionTurn } from '@/lib/discussion'
import { generateDiscussion, type DiscussionRun } from '@/lib/discussion-client'
import { mutate } from 'swr'
import { resourceKey } from '@/lib/resources'

const emptyRun: DiscussionRun = { agents: hats, topic: '', rounds: 1, durationSeconds: 300, elapsedSeconds: 0, elapsedOffsetSeconds: 0, maxLength: 300, runId: '' }
type Speaking = { agentId: string; sequence: number; startedAt: number; readHostIds: string[]; selectionReason: string }
export function useDiscussion() {
  const [messages, setMessages] = useState<Message[]>([])
  const [status, setStatus] = useState<Status>('ready')
  const [run, setRun] = useState<DiscussionRun>(emptyRun)
  const [remainingSeconds, setRemainingSeconds] = useState(300)
  const [speaking, setSpeaking] = useState<Speaking | null>(null)
  const [draft, setDraft] = useState('')
  const [isPreview, setIsPreview] = useState(false)
  const [error, setError] = useState('')
  const [summary, setSummary] = useState('')
  const [summaryLoading, setSummaryLoading] = useState(false)
  const [summaryError, setSummaryError] = useState('')
  const session = useRef({ run: emptyRun, messages: [] as Message[], version: 0, nextSequence: 1, deadline: 0, remaining: 300, phase: 'idle' })
  const controller = useRef<AbortController | null>(null)
  const summaryController = useRef<AbortController | null>(null)
  const active = run.agents.find(agent => agent.id === speaking?.agentId)

  useEffect(() => () => { controller.current?.abort(); summaryController.current?.abort() }, [])
  useEffect(() => {
    if (status !== 'running') return
    const tick = () => {
      const current = session.current
      if (!current.deadline) return
      const remaining = Math.max(0, (current.deadline - Date.now()) / 1000)
      setRemainingSeconds(remaining)
      if (remaining <= 0) {
        checkpointClock(true)
        cancelTurn()
        setStatus('completed')
      } else if ((current.run.elapsedSeconds ?? 0) < 180 && (current.run.durationSeconds ?? 300) - remaining >= 180) {
        checkpointClock()
      }
    }
    tick()
    const timer = setInterval(tick, 500)
    return () => clearInterval(timer)
  }, [status])

  function releaseTurn() {
    session.current.phase = 'idle'
    session.current.nextSequence = Math.max(0, ...session.current.messages.map(message => message.sequence ?? 0)) + 1
    setSpeaking(null); setDraft('')
  }
  function cancelTurn() { session.current.version++; controller.current?.abort(); controller.current = null; releaseTurn() }
  function invalidateSummary() { summaryController.current?.abort(); summaryController.current = null; setSummary(''); setSummaryLoading(false); setSummaryError('') }
  function updateMessages(next: Message[]) { session.current.messages = next; setMessages(next) }
  function checkpointClock(freeze = false) {
    const current = session.current
    if (current.deadline) current.remaining = Math.max(0, (current.deadline - Date.now()) / 1000)
    if (freeze) current.deadline = 0
    current.run = { ...current.run, elapsedSeconds: (current.run.elapsedOffsetSeconds ?? 0) + (current.run.durationSeconds ?? 300) - current.remaining }
    setRun(current.run); setRemainingSeconds(current.remaining)
  }

  async function execute() {
    cancelTurn(); invalidateSummary()
    const version = session.current.version
    const abort = new AbortController()
    controller.current = abort
    setError(''); setStatus('running')
    try {
      while (Date.now() < session.current.deadline) {
        const current = session.current
        if (current.messages.length >= 249) throw new Error('本场讨论已达到记录容量，请结束并导出后开启新话题。')
        current.phase = 'selecting'
        const context = discussionContext([...current.messages])
        let decision: { agentId: string; reason: string }
        if (current.run.agents.length === 1) decision = { agentId: current.run.agents[0].id, reason: '当前唯一参与角色继续回应' }
        else {
          const raw = await generateDiscussion(current.run, context, current.nextSequence, 'select', abort.signal, () => {})
          try {
            decision = JSON.parse(raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''))
            if (!current.run.agents.some(agent => agent.id === decision.agentId) || typeof decision.reason !== 'string' || !decision.reason.trim() || decision.reason.length > 1000) throw new Error()
          } catch { throw new Error('模型未返回有效的发言选择，请点击继续推演重试。') }
        }
        if (abort.signal.aborted || session.current.version !== version) return
        if (Date.now() >= current.deadline) break
        const agent = current.run.agents.find(item => item.id === decision.agentId)!
        const metadata: Speaking = { agentId: agent.id, sequence: current.nextSequence++, startedAt: Date.now(), readHostIds: context.filter(message => message.agentId === 'host').map(message => message.id), selectionReason: decision.reason }
        current.phase = 'speaking'; setSpeaking(metadata)
        const content = await generateDiscussion(current.run, context, metadata.sequence, 'turn', abort.signal, text => {
          if (session.current.version === version && !abort.signal.aborted) setDraft(text)
        }, agent.id, decision.reason)
        if (abort.signal.aborted || session.current.version !== version) return
        const message: Message = { id: crypto.randomUUID(), ...metadata, content, timestamp: Date.now(), round: 1 }
        updateMessages(insertDiscussionTurn(current.messages, message)); checkpointClock()
        void mutate(resourceKey(current.run.runId))
        current.phase = 'idle'; setSpeaking(null); setDraft('')
      }
      if (session.current.version === version) { checkpointClock(true); setStatus('completed'); setSpeaking(null) }
    } catch (cause) {
      if (!abort.signal.aborted && session.current.version === version) {
        checkpointClock(true)
        setError(cause instanceof Error ? cause.message : '模型调用失败，请重试。')
        setStatus(session.current.remaining <= 0 ? 'completed' : 'paused'); releaseTurn()
      }
    } finally { if (controller.current === abort) { controller.current = null; session.current.phase = 'idle' } }
  }

  function start(agents: Agent[], topic: string, durationMinutes: number, maxLength: number) {
    if (!agents.length || !topic.trim()) return
    cancelTurn(); invalidateSummary()
    const durationSeconds = Math.max(60, Math.min(1800, Math.round(durationMinutes * 60)))
    const nextRun = { agents: [...agents], topic: topic.trim(), rounds: 1, durationSeconds, elapsedSeconds: 0, elapsedOffsetSeconds: 0, maxLength, runId: crypto.randomUUID() }
    Object.assign(session.current, { run: nextRun, nextSequence: 1, remaining: durationSeconds, deadline: Date.now() + durationSeconds * 1000 })
    setRun(nextRun); updateMessages([]); setRemainingSeconds(durationSeconds); setIsPreview(false)
    void execute()
  }
  function continueFromHistory(durationMinutes: number) {
    const current = session.current
    const elapsedSeconds = current.run.elapsedSeconds ?? 0
    const availableSeconds = 7200 - elapsedSeconds
    if (!current.run.runId || current.messages.length === 0 || current.messages.length >= 249 || availableSeconds < 60) return false
    const requestedSeconds = Math.max(60, Math.min(1800, Math.round(durationMinutes * 60)))
    const durationSeconds = Math.min(requestedSeconds, availableSeconds)
    cancelTurn(); invalidateSummary()
    const nextRun = { ...current.run, durationSeconds, elapsedSeconds, elapsedOffsetSeconds: elapsedSeconds, continuedFromHistory: true }
    Object.assign(current, { run: nextRun, remaining: durationSeconds, deadline: Date.now() + durationSeconds * 1000 })
    setRun(nextRun); setRemainingSeconds(durationSeconds); setIsPreview(false); setError('')
    void execute()
    return true
  }
  function reset() {
    cancelTurn(); invalidateSummary()
    Object.assign(session.current, { run: emptyRun, nextSequence: 1, remaining: 300, deadline: 0 })
    setRun(emptyRun); updateMessages([]); setStatus('ready'); setRemainingSeconds(300); setIsPreview(false); setError('')
  }
  function intervene(content: string) {
    if (!content.trim() || !['running', 'paused'].includes(status) || session.current.messages.length >= 249) return false
    invalidateSummary()
    const current = session.current
    const selecting = status === 'running' && current.phase !== 'speaking'
    updateMessages([...current.messages, { id: crypto.randomUUID(), agentId: 'host', content: content.trim().slice(0, 1000), timestamp: Date.now(), round: 1, sequence: current.nextSequence++ }])
    if (selecting) void execute()
    return true
  }
  async function generateSummary() {
    if (summaryController.current || isPreview || !session.current.messages.some(message => message.agentId !== 'host') || status === 'running') return
    const abort = new AbortController()
    summaryController.current = abort
    setSummary(''); setSummaryError(''); setSummaryLoading(true)
    try {
      await generateDiscussion(session.current.run, [...session.current.messages], 1, 'summary', abort.signal, text => { if (!abort.signal.aborted) setSummary(text) })
      if (!abort.signal.aborted) void mutate(resourceKey(session.current.run.runId))
    } catch (cause) {
      if (!abort.signal.aborted) { setSummary(''); setSummaryError(cause instanceof Error ? cause.message : '总结失败，请重试。') }
    } finally { if (summaryController.current === abort) { summaryController.current = null; setSummaryLoading(false) } }
  }
  function toggleMessageMark(messageId: string, mark: MessageMark) {
    const current = session.current.messages
    const target = current.find(message => message.id === messageId)
    if (!target || target.agentId === 'host' || mark.start < 0 || mark.end <= mark.start || mark.end > target.content.length) return null
    const marks = target.marks ?? []
    const existingIndex = marks.findIndex(item => item.start === mark.start && item.end === mark.end && item.kind === mark.kind)
    if (existingIndex < 0 && marks.length >= 100) return { messages: current, changed: false, added: false }
    const nextMarks = existingIndex >= 0 ? marks.filter((_, index) => index !== existingIndex) : [...marks, mark]
    const next = current.map(message => message.id === messageId ? { ...message, marks: nextMarks } : message)
    updateMessages(next)
    return { messages: next, changed: true, added: existingIndex < 0 }
  }

  return {
    messages, status, draft, active, speaking, remainingSeconds, isPreview, run, error, summary, summaryLoading, summaryError, generateSummary, toggleMessageMark,
    restore: (saved: { run: DiscussionRun; messages: Message[]; summary: string; preview: boolean }) => {
      cancelTurn(); invalidateSummary()
      const elapsedInSegment = Math.max(0, (saved.run.elapsedSeconds ?? 0) - (saved.run.elapsedOffsetSeconds ?? 0))
      const remaining = Math.max(0, (saved.run.durationSeconds ?? 300) - elapsedInSegment)
      Object.assign(session.current, { run: saved.run, remaining, deadline: 0, nextSequence: Math.max(0, ...saved.messages.map(message => message.sequence ?? 0)) + 1 })
      setRun(saved.run); updateMessages(saved.messages); setRemainingSeconds(remaining)
      setSummary(saved.summary); setIsPreview(saved.preview); setStatus('stopped'); setError('')
    },
    progress: Math.min(100, Math.max(0, 100 * (1 - remainingSeconds / (run.durationSeconds ?? 300)))), start, continueFromHistory, reset, intervene,
    pause: () => { checkpointClock(true); cancelTurn(); setStatus(session.current.remaining > 0 ? 'paused' : 'completed') },
    resume: () => { if (status === 'paused' && session.current.remaining > 0) { session.current.deadline = Date.now() + session.current.remaining * 1000; void execute() } },
    stop: () => { checkpointClock(true); cancelTurn(); setStatus('stopped'); setError('') },
  }
}
