import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Noto_Sans_SC } from 'next/font/google'
import './globals.css'

const notoSans = Noto_Sans_SC({ subsets: ['latin'], weight: ['400', '500', '600'], display: 'swap', variable: '--font-noto-sans' })

export const metadata: Metadata = {
  title: 'SynapseRound — 多一个视角，多一种可能',
  description: '多角色思维风暴与用户访谈模拟工作台。用六顶思考帽探索产品价值，手动记录关键洞察与下一步行动，重开历史话题优先回顾成果，也可上传资料并追溯观点来源。',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f8f9f7' },
    { media: '(prefers-color-scheme: dark)', color: '#171d19' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    // Browser extensions can inject attributes on the root element before hydration.
    <html lang="zh-CN" suppressHydrationWarning>
      <body className={`${notoSans.variable} antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
