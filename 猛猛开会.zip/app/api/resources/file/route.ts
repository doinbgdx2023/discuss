import { z } from 'zod'
import { downloadResource, readResource, resourceSpace, validRequestOrigin } from '@/lib/resources-server'
export const runtime = 'nodejs'
export async function GET(request: Request) {
  if (!validRequestOrigin(request)) return new Response('请求来源无效', { status: 403 })
  const space = await resourceSpace()
  if (!space) return new Response('未授权访问', { status: 401 })
  const id = new URL(request.url).searchParams.get('id')
  if (!z.uuid().safeParse(id).success) return new Response('资料标识无效', { status: 400 })
  try {
    const record = await readResource(space, id!)
    if (!record || record.kind !== 'upload') return new Response('文件不存在', { status: 404 })
    const result = await downloadResource(space, id!)
    if (!result || result.statusCode !== 200) return new Response('文件不存在', { status: 404 })
    return new Response(result.stream, { headers: {
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': `attachment; filename="reference"; filename*=UTF-8''${encodeURIComponent(record.filename ?? record.title)}`,
      'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff',
    } })
  } catch { return new Response('暂时无法下载文件', { status: 503 }) }
}
