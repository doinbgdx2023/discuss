import { z } from 'zod'
import { extractText, getDocumentProxy } from 'unpdf'
import { extractRawText } from 'mammoth'
import { listResources, listUsage, removeResource, resourceSpace, saveResource, validRequestOrigin } from '@/lib/resources-server'
import type { ResourceView } from '@/lib/resources'

export const runtime = 'nodejs'
export const maxDuration = 60
const roleSchema = z.array(z.string().min(1).max(100)).max(6)
const maxSize = 4 * 1024 * 1024

export async function GET(request: Request) {
  if (!validRequestOrigin(request)) return Response.json({ error: '请求来源无效。' }, { status: 403 })
  const runId = new URL(request.url).searchParams.get('runId')
  if (runId && !z.uuid().safeParse(runId).success) return Response.json({ error: '讨论标识无效。' }, { status: 400 })
  try {
    const space = (await resourceSpace(true))!
    const [records, usages] = await Promise.all([listResources(space), runId ? listUsage(space, runId) : Promise.resolve([])])
    const resources: ResourceView[] = records.map(({ text, ...record }) => ({
      ...record, preview: text.slice(0, 600),
      providedTo: [...new Set(usages.filter(usage => usage.provided.includes(record.id)).map(usage => usage.agentId))],
      citedBy: [...new Set(usages.filter(usage => usage.cited.includes(record.id)).map(usage => usage.agentId))],
      citations: usages.filter(usage => usage.cited.includes(record.id)).map(usage => ({ agentId: usage.agentId, round: usage.round, number: usage.provided.indexOf(record.id) + 1 })),
    }))
    return Response.json({ resources }, { headers: { 'Cache-Control': 'private, no-store' } })
  } catch {
    return Response.json({ error: '资料库暂时不可用，请稍后重试。' }, { status: 503 })
  }
}

export async function POST(request: Request) {
  if (!validRequestOrigin(request)) return Response.json({ error: '请求来源无效。' }, { status: 403 })
  const space = await resourceSpace()
  if (!space) return Response.json({ error: '请先打开参考资料，初始化工作空间。' }, { status: 401 })
  if (Number(request.headers.get('content-length')) > maxSize + 20000) return Response.json({ error: '单个文件不能超过 4 MB。' }, { status: 413 })
  try {
    const form = await request.formData()
    const file = form.get('file')
    if (!(file instanceof File) || !file.size || file.size > maxSize) return Response.json({ error: '请选择非空文件，单个文件不能超过 4 MB。' }, { status: 400 })
    const roles = roleSchema.safeParse(JSON.parse(String(form.get('agentIds') ?? '[]')))
    if (!roles.success) return Response.json({ error: '阅读角色配置无效。' }, { status: 400 })
    const ext = file.name.split('.').at(-1)?.toLowerCase()
    if (!['txt', 'md', 'pdf', 'docx'].includes(ext ?? '')) return Response.json({ error: '支持 TXT、Markdown、PDF、DOCX 文件。' }, { status: 415 })
    if ((await listResources(space)).length >= 60) return Response.json({ error: '最多保存 60 份资料，请先移除不需要的文件。' }, { status: 409 })
    const buffer = Buffer.from(await file.arrayBuffer())
    let text = ''
    if (ext === 'pdf') {
      if (buffer.subarray(0, 5).toString() !== '%PDF-') return Response.json({ error: '文件不是有效 PDF。' }, { status: 400 })
      const pdf = await getDocumentProxy(new Uint8Array(buffer))
      try {
        if (pdf.numPages > 100) return Response.json({ error: 'PDF 最多支持 100 页。' }, { status: 400 })
        text = (await extractText(pdf, { mergePages: true })).text
      } finally { await pdf.loadingTask.destroy() }
    } else if (ext === 'docx') {
      if (buffer.subarray(0, 2).toString() !== 'PK') return Response.json({ error: '文件不是有效 DOCX。' }, { status: 400 })
      text = (await extractRawText({ buffer })).value
    } else {
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(buffer) } catch { return Response.json({ error: '文本文件请使用 UTF-8 编码。' }, { status: 400 }) }
    }
    text = text.replace(/\u0000/g, '').trim()
    if (!text) return Response.json({ error: '没有识别到可阅读的文字。扫描版 PDF 请先做 OCR。' }, { status: 422 })
    await saveResource(space, {
      id: crypto.randomUUID(), title: file.name.slice(0, 150), filename: file.name.slice(0, 150),
      kind: 'upload', agentIds: roles.data, createdAt: new Date().toISOString(), size: file.size,
      text: text.slice(0, 30000), truncated: text.length > 30000,
    }, file)
    return Response.json({ success: true }, { status: 201 })
  } catch {
    return Response.json({ error: '上传或解析失败，请检查文件是否损坏并重试。' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  if (!validRequestOrigin(request)) return Response.json({ error: '请求来源无效。' }, { status: 403 })
  const space = await resourceSpace()
  if (!space) return Response.json({ error: '未找到资料工作空间。' }, { status: 401 })
  const id = new URL(request.url).searchParams.get('id')
  if (!z.uuid().safeParse(id).success) return Response.json({ error: '资料标识无效。' }, { status: 400 })
  try {
    const removed = await removeResource(space, id!)
    return removed ? Response.json({ success: true }) : Response.json({ error: '资料不存在。' }, { status: 404 })
  } catch { return Response.json({ error: '删除失败，请重试。' }, { status: 500 }) }
}
