import { NextResponse } from 'next/server'
import { createHash } from 'node:crypto'
import { and, desc, eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '@/lib/db'
import { discussionHistory as table } from '@/lib/db/schema'
import { resourceSpace, validRequestOrigin } from '@/lib/resources-server'
export const runtime = 'nodejs'
const agent = z.object({ id: z.string().max(100), name: z.string().max(100), subtitle: z.string().max(1000), color: z.string().max(30), focus: z.string().max(1000), prompt: z.string().max(10000) })
const messageMark = z.object({ start: z.number().int().min(0).max(30000), end: z.number().int().min(1).max(30000), kind: z.enum(['highlight', 'point', 'bold']) }).refine(mark => mark.end > mark.start, { message: '标注范围无效。' })
const message = z.object({ id: z.string().max(100), agentId: z.string().max(100), content: z.string().max(30000), timestamp: z.number(), round: z.number().int().min(0).max(20), targetAgentId: z.string().max(100).optional(), sequence: z.number().int().min(1).max(10000).optional(), startedAt: z.number().optional(), readHostIds: z.array(z.string().max(100)).max(250).optional(), selectionReason: z.string().max(1000).optional(), marks: z.array(messageMark).max(100).optional() }).refine(value => (value.marks ?? []).every(mark => mark.end <= value.content.length), { message: '标注范围超出发言内容。', path: ['marks'] })
const snapshot = z.object({ run: z.object({ runId: z.uuid(), topic: z.string().trim().min(1).max(10000), agents: z.array(agent).min(1).max(10), rounds: z.number().int().min(1).max(20), maxLength: z.number().int().min(1).max(5000), durationSeconds: z.number().int().min(60).max(1800).optional(), elapsedSeconds: z.number().min(0).max(7200).optional(), elapsedOffsetSeconds: z.number().min(0).max(7200).optional(), continuedFromHistory: z.boolean().optional() }), messages: z.array(message).max(250), summary: z.string().max(50000), mode: z.enum(['hats', 'personas']), preview: z.boolean() })
const note = z.object({ id: z.uuid(), conclusion: z.string().trim().min(1).max(2000), action: z.string().max(4000), done: z.boolean(), important: z.boolean().optional(), sourceId: z.string().max(100), sourceName: z.string().max(100), sourceRound: z.number().int().min(0).max(20), sourceSequence: z.number().int().min(1).max(10000).optional(), sourceText: z.string().max(30000), createdAt: z.iso.datetime() })
const input = z.object({ snapshot: snapshot.optional(), note: note.optional(), removeNoteId: z.uuid().optional(), id: z.uuid() })
async function owner(create = false) { const space = await resourceSpace(create); return space ? createHash('sha256').update(space).digest('hex') : null }
async function items(userId: string | null) { return userId ? db.select({ id: table.id, snapshot: table.snapshot, notes: table.notes, updatedAt: table.updatedAt }).from(table).where(eq(table.userId, userId)).orderBy(desc(table.updatedAt)).limit(100) : [] }
function failed() { return NextResponse.json({ error: process.env.DATABASE_URL ? '历史记录暂时不可用。尚未保存的更改请勿关闭，稍后重试。' : 'Neon 已连接，但 DATABASE_URL 尚未同步到项目，请在项目集成设置中检查连接。更改尚未保存，请不要关闭。' }, { status: 503 }) }
export async function GET() {
  try { if (!process.env.DATABASE_URL) return failed(); return NextResponse.json({ items: await items(await owner()) }, { headers: { 'Cache-Control': 'private, no-store' } }) } catch { return failed() }
}
export async function POST(request: Request) {
  if (!validRequestOrigin(request)) return NextResponse.json({ error: '请求来源无效。' }, { status: 403 })
  if (!process.env.DATABASE_URL) return failed()
  if (Number(request.headers.get('content-length') || 0) > 2000000) return NextResponse.json({ error: '讨论记录过大。' }, { status: 413 })
  const parsed = input.safeParse(await request.json().catch(() => null))
  if (!parsed.success || (parsed.data.snapshot && parsed.data.id !== parsed.data.snapshot.run.runId)) return NextResponse.json({ error: '记录格式无效。' }, { status: 400 })
  try {
    const userId = (await owner(true))!
    const data = parsed.data
    await db.transaction(async tx => {
      if (data.snapshot) await tx.insert(table).values({ id: data.id, userId, snapshot: data.snapshot }).onConflictDoUpdate({ target: [table.userId, table.id], set: { snapshot: data.note ? table.snapshot : data.snapshot, updatedAt: new Date() } })
      if (data.note || data.removeNoteId) {
        const [record] = await tx.select().from(table).where(and(eq(table.id, data.id), eq(table.userId, userId))).for('update')
        if (!record) throw new Error('not found')
        let notes = record.notes.filter(item => item.id !== (data.note?.id ?? data.removeNoteId))
        if (data.note) notes = [data.note, ...notes]
        if (notes.length > 100) throw new Error('note limit')
        await tx.update(table).set({ notes, updatedAt: new Date() }).where(and(eq(table.id, data.id), eq(table.userId, userId)))
      }
    })
    return NextResponse.json({ items: await items(userId) })
  } catch { return failed() }
}
