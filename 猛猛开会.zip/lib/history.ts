import type { Agent, Message, Mode } from '@/lib/discussion'
import type { DiscussionRun } from '@/lib/discussion-client'

export type Snapshot = { run: DiscussionRun; messages: Message[]; summary: string; mode: Mode; preview: boolean }
export type Insight = { id: string; conclusion: string; action: string; done: boolean; important?: boolean; sourceId: string; sourceName: string; sourceRound: number; sourceSequence?: number; sourceText: string; createdAt: string }
export function prioritizeInsights(notes: Insight[]) {
  return [...notes].sort((a, b) => Number(!!b.important) - Number(!!a.important) || b.createdAt.localeCompare(a.createdAt))
}
export type HistoryItem = { id: string; snapshot: Snapshot; notes: Insight[]; updatedAt: string }
export function qualifiesForHistory(snapshot: Snapshot) {
  if (snapshot.preview || snapshot.run.continuedFromHistory) return true
  return snapshot.run.elapsedSeconds === undefined || snapshot.run.elapsedSeconds >= 180
}
export const historyKey = '/api/history'
export async function historyRequest(body?: unknown): Promise<{ items: HistoryItem[] }> {
  const response = await fetch(historyKey, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined)
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || '保存失败，请重试。')
  return data
}
export function exportInsights(notes: Insight[]) {
  return notes.length ? '\n\n## 我的洞察与下一步\n\n' + prioritizeInsights(notes).map(note => `### ${note.important ? '重点洞察 · ' : ''}${note.conclusion}\n\n- 下一步：${note.action || '待补充'}\n- 状态：${note.done ? '已完成' : '待行动'}\n- 来源：${note.sourceName || '整场讨论'}${note.sourceSequence ? ` · 发言 #${note.sourceSequence}` : note.sourceRound ? ` · 历史第${note.sourceRound}轮` : ''}\n\n${note.sourceText ? `> ${note.sourceText.replaceAll('\n', '\n> ')}` : ''}`).join('\n\n') : ''
}
export function agentName(agent: Agent | undefined) { return agent?.name ?? '主持人' }
