export type Resource = {
  id: string
  title: string
  kind: 'upload' | 'web'
  agentIds: string[]
  createdAt: string
  size?: number
  filename?: string
  url?: string
  text: string
  truncated?: boolean
}
export type ResourceView = Omit<Resource, 'text'> & {
  preview: string
  providedTo: string[]
  citedBy: string[]
  citations: { agentId: string; round: number; number: number }[]
}
export type ResourceUsage = {
  agentId: string
  round: number
  provided: string[]
  cited: string[]
}
export const resourceKey = (runId: string) => `/api/resources?runId=${encodeURIComponent(runId)}`
export async function resourceFetcher(url: string): Promise<{ resources: ResourceView[] }> {
  const response = await fetch(url)
  const data = await response.json()
  if (!response.ok) throw new Error(data.error ?? '资料读取失败，请重试。')
  return data
}
export function exportResources(resources: ResourceView[], names: Record<string, string>) {
  if (!resources.length) return ''
  return '\n\n## 参考资料\n' + resources.map(resource => {
    const roles = resource.citations.map(citation => `${names[citation.agentId] ?? citation.agentId} 发言编号 ${citation.round} [资料${citation.number}]`).join('、')
    return `\n- ${resource.title}${resource.url ? `（${resource.url}）` : '（上传文件）'}${roles ? ` · 发言引用：${roles}` : ' · 未标注引用'}`
  }).join('')
}
