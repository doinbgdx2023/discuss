import 'server-only'
import { cookies } from 'next/headers'
import { randomBytes } from 'node:crypto'
import { get, list, put, del } from '@vercel/blob'
import type { Resource, ResourceUsage } from '@/lib/resources'

const cookieName = 'synapse-resource-space'
export function validRequestOrigin(request: Request) {
  const origin = request.headers.get('origin')
  const host = request.headers.get('x-forwarded-host')?.split(',')[0].trim() ?? request.headers.get('host') ?? new URL(request.url).host
  const site = request.headers.get('sec-fetch-site')
  return site !== 'cross-site' && (!origin || (URL.canParse(origin) && (site === 'same-origin' || new URL(origin).host === host)))
}
export async function resourceSpace(create = false) {
  const jar = await cookies()
  const current = jar.get(cookieName)?.value
  if (current && /^[a-f0-9]{64}$/.test(current)) return current
  if (!create) return null
  const value = randomBytes(32).toString('hex')
  // An unguessable HttpOnly capability isolates anonymous workspaces; this is not account authentication.
  jar.set(cookieName, value, { httpOnly: true, secure: true, sameSite: 'none', path: '/', maxAge: 60 * 60 * 24 * 365 })
  return value
}
function root(space: string) { return `synapse-resources/${space}/` }
async function readJson<T>(pathname: string): Promise<T | null> {
  const result = await get(pathname, { access: 'private', useCache: false })
  if (!result || result.statusCode !== 200) return null
  return JSON.parse(await new Response(result.stream).text()) as T
}
export async function readResource(space: string, id: string) {
  return readJson<Resource>(`${root(space)}records/${id}.json`)
}
export async function listResources(space: string) {
  const result = await list({ prefix: `${root(space)}records/`, limit: 61 })
  const records = await Promise.all(result.blobs.map(blob => readJson<Resource>(blob.pathname)))
  return records.filter((record): record is Resource => record !== null).sort((a, b) => a.createdAt.localeCompare(b.createdAt))
}
export async function saveResource(space: string, resource: Resource, file?: File) {
  const recordPath = `${root(space)}records/${resource.id}.json`
  const filePath = `${root(space)}files/${resource.id}`
  if (file) await put(filePath, file, { access: 'private', addRandomSuffix: false, contentType: 'application/octet-stream' })
  try {
    await put(recordPath, JSON.stringify(resource), { access: 'private', addRandomSuffix: false, contentType: 'application/json' })
  } catch (error) {
    if (file) await del(filePath).catch(() => {})
    throw error
  }
}
export async function removeResource(space: string, id: string) {
  const record = await readResource(space, id)
  if (!record) return false
  await del(`${root(space)}records/${id}.json`)
  if (record.kind === 'upload') await del(`${root(space)}files/${id}`)
  return true
}
export async function downloadResource(space: string, id: string) {
  return get(`${root(space)}files/${id}`, { access: 'private', useCache: false })
}
export async function recordUsage(space: string, runId: string, usage: ResourceUsage) {
  await put(`${root(space)}usage/${runId}/${crypto.randomUUID()}.json`, JSON.stringify(usage), { access: 'private', addRandomSuffix: false, contentType: 'application/json' })
}
export async function listUsage(space: string, runId: string) {
  const result = await list({ prefix: `${root(space)}usage/${runId}/`, limit: 200 })
  const records = await Promise.all(result.blobs.map(blob => readJson<ResourceUsage>(blob.pathname)))
  return records.filter((record): record is ResourceUsage => record !== null)
}
