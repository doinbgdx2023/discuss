import { pgTable, uuid, text, jsonb, timestamp, primaryKey } from 'drizzle-orm/pg-core'
import type { Snapshot, Insight } from '@/lib/history'
export const discussionHistory = pgTable('discussion_history', {
  id: uuid('id').notNull(),
  userId: text('userId').notNull(),
  snapshot: jsonb('snapshot').$type<Snapshot>().notNull(),
  notes: jsonb('notes').$type<Insight[]>().notNull().default([]),
  createdAt: timestamp('createdAt', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updatedAt', { withTimezone: true }).notNull().defaultNow(),
}, table => [primaryKey({ columns: [table.userId, table.id] })])
