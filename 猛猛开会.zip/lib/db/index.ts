import 'server-only'
import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from './schema'
const globalDb = globalThis as unknown as { synapsePool?: Pool }
export const pool = globalDb.synapsePool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 3, connectionTimeoutMillis: 10000 })
if (process.env.NODE_ENV !== 'production') globalDb.synapsePool = pool
export const db = drizzle(pool, { schema })
