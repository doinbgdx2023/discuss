import { type Agent, type Message, discussionContext } from '@/lib/discussion'

export type DiscussionRun = { agents: Agent[]; topic: string; rounds: number; maxLength: number; runId: string; durationSeconds?: number; elapsedSeconds?: number; elapsedOffsetSeconds?: number; continuedFromHistory?: boolean }

export async function generateDiscussion(run: DiscussionRun, messages: Message[], round: number, kind: 'turn' | 'summary' | 'select', signal: AbortSignal, onText: (text: string) => void, agentId?: string, selectionReason?: string) {
  const response = await fetch('/api/discussion', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, signal,
    body: JSON.stringify({ ...run, round, messages: discussionContext(messages), kind, agentId, selectionReason }),
  })
  if (!response.ok) {
    const data = await response.json().catch(() => null)
    throw new Error(data?.error ?? '无法连接模型服务，请稍后重试。')
  }
  if (!response.body) throw new Error('模型未返回内容，请重试。')
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let text = ''
  let completed = false
  function process(line: string) {
    if (!line.trim()) return
    const event = JSON.parse(line)
    if (event.type === 'error') throw new Error(event.message)
    if (event.type === 'done') completed = true
    if (event.type === 'delta' && typeof event.text === 'string') { text += event.text; onText(text) }
  }
  try {
    while (true) {
      const chunk = await reader.read()
      buffer += decoder.decode(chunk.value, { stream: !chunk.done })
      const lines = buffer.split('\n')
      buffer = lines.pop() ?? ''
      lines.forEach(process)
      if (chunk.done) break
    }
    process(buffer)
    if (!completed || !text.trim()) throw new Error('模型回复中断，请点击继续推演重试当前角色。')
    return text.trim()
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock() }
}
