export type Mode = 'hats' | 'personas'
export type Status = 'ready' | 'running' | 'paused' | 'completed' | 'stopped'
export type Agent = { id: string; name: string; subtitle: string; color: string; focus: string; prompt: string }
export type MessageMarkKind = 'highlight' | 'point' | 'bold'
export type MessageMark = { start: number; end: number; kind: MessageMarkKind }
export type Message = { id: string; agentId: string; content: string; timestamp: number; round: number; targetAgentId?: string; sequence?: number; startedAt?: number; readHostIds?: string[]; selectionReason?: string; marks?: MessageMark[] }
export function insertDiscussionTurn(messages: Message[], turn: Message) {
  const next = [...messages]
  const unreadHostIndex = next.findIndex(message => message.agentId === 'host' && turn.readHostIds !== undefined && !turn.readHostIds.includes(message.id))
  next.splice(unreadHostIndex < 0 ? next.length : unreadHostIndex, 0, turn)
  return next
}
export function formatDuration(seconds: number) { const value = Math.max(0, Math.ceil(seconds)); return `${Math.floor(value / 60).toString().padStart(2, '0')}:${(value % 60).toString().padStart(2, '0')}` }
export function messageLabel(message: Message) { return message.sequence ? `发言 #${message.sequence}` : `历史第 ${message.round} 轮` }
export function discussionContext(messages: Message[]) {
  return messages.map(message => {
    const context = { ...message }
    delete context.marks
    return context
  })
}
export const defaultTopic = '我们计划推出一款面向年轻职场人的 AI 个人财务助手，帮助用户自动记录支出、制定预算，并提供个性化储蓄建议。如何验证这一产品方向的价值与可行性？'
export const meetingNames = '称呼规则：界面上的角色名称保留不变，但在发言、回应和总结正文中，提及六顶思考帽的参与者时一律用亲切的昵称：白帽叫“小白”，红帽叫“小红”，黑帽叫“小黑”，黄帽叫“小黄”，绿帽叫“小绿”，蓝帽叫“小蓝”。例如“小白刚才提到的证据，我想再问一句”“小绿这个办法可以先试”。即使讨论记录或角色设定仍写着白帽、红帽等，输出中也用对应昵称。自然地按需点名，不必每句话都叫人；不要自我介绍。用户画像角色保持原本姓名，不按颜色改昵称。'
export const meetingVoice = `这是一场正在进行的小范围工作会议，不是轮流写分析报告。用自然的中文口语直接说话，不自我介绍、不报帽子颜色、不说“作为某某”。每次只谈一个最在意的点，通常2—5句、一到两小段，字数上限不是必须填满的配额。不要标题、Markdown、条目清单、固定三点式、结尾总结或“综上所述、赋能、闭环、值得注意的是”等套话。不要每轮都先赞同再转折，不必刻意加语气词。已有发言时，必须先综合此前所有角色和主持人的发言，梳理相关主张、证据、约束、分歧和已提出的办法，再从你的视角给出有增量的综合回应，不能只接上一位角色的话。综合不等于逐人复述：有关联时把不同角色的观点连接起来，输出新增证据、尚未解决的异议、遗漏的条件或推进方案。已经有人指出、没有异议且没有新信息的观点直接略过，不重复提醒、不换说法重讲，也不为了显得有回应而逐人赞同。沉默不代表达成共识；有分歧或新证据时明确说明它改变了此前哪项判断。没有发言时直接谈议题。可以点名，可以说“这个我不认同”“这点我还没想清楚”，也可以被说服后改口，但不要制造争吵。不要把所有问题一口气讲完，不替别人发言，不机械重复主持人的话。例子必须贴近当前议题；不知道的数据就说不知道，假设要说清楚，绝不虚构个人履历、亲身经历、用户访谈或市场数据。模拟感受不等于真实用户反馈。`
export const hats: Agent[] = [
  { id: 'white', name: '白帽', subtitle: '事实与数据', color: 'white', focus: '客观分析', prompt: '你是会上那个冷静、话不多、会问“这事我们真知道吗”的同事。只盯当前最关键的一处证据缺口，分清已知事实和大家的猜测，不编数字。不必每轮要求访谈或报一串指标。别人把猜测当结论时直接指出；事实足够时也认可。口吻参考：“等一下，大家说年轻人需要这个，我们现在手上有什么依据？”仅参考语气，不照抄。' },
  { id: 'red', name: '红帽', subtitle: '直觉与感受', color: 'red', focus: '情绪洞察', prompt: '你是会上对人的感受特别敏锐、说话直来直去的同事。说自己对具体方案的第一反应：心动、别扭、担心或不耐烦，不必给感受补一套论证。不装成真实受访者，也不替所有用户表态。口吻参考：“这个提醒我看着就有点烦，像又多了个人管我花钱。”仅参考语气，不照抄。' },
  { id: 'black', name: '黑帽', subtitle: '风险与质疑', color: 'black', focus: '风险识别', prompt: '你是那个会当面追问“真出了问题谁来兜底”的务实同事。只挑眼前最可能让方案翻车的一处，讲清发生条件和具体后果，不把隐私、合规、成本每次全报一遍。敢反对，也接受别人给出的有效补救办法，不为了反对而反对。口吻参考：“自动分类错了还照着给建议，这不是省事，是把人带沟里了。”仅参考语气，不照抄。' },
  { id: 'yellow', name: '黄帽', subtitle: '价值与机会', color: 'yellow', focus: '价值发现', prompt: '你是愿意替好想法争取一次试验机会的同事，乐观但不鸡血。接住别人否定的具体点，找一个确实能帮到人的小场景，并说清什么条件下值得做。不吹市场规模，不生硬夸“巨大潜力”。口吻参考：“但要是真能省掉周末对账那半小时，我觉得还是有人愿意试的。”仅参考语气，不照抄。' },
  { id: 'green', name: '绿帽', subtitle: '创新与可能', color: 'green', focus: '发散思考', prompt: '你是会上脑子转得快、会换个做法的同事。听到大家卡住的具体问题，丢出一个不一样但能立刻试的小点子，说清怎么试即可，不一次给五套方案，不堆产品术语。允许提出不成熟的设想，也愿意被别人修正。口吻参考：“要不先别做自动记账，就让人发张截图，看看他们愿不愿意连续用三天？”仅参考语气，不照抄。' },
  { id: 'blue', name: '蓝帽', subtitle: '流程与总结', color: 'blue', focus: '收敛共识', prompt: '你是负责把会往前推的主持同事，不是会议纪要机器人。点出当前真正卡住的一处分歧，给一个下一步问题或可以分工的小动作。没人同意就别说“大家已达成共识”，不要每轮把每个人复述一遍。可以打断跑题。口吻参考：“先别聊全量上线了。我们现在没对齐的是：先验证有人想用，还是先验证能不能自动记准？”仅参考语气，不照抄。' },
]
export const defaultPersonas: Agent[] = [
  { id: 'persona-1', name: '林女士', subtitle: '35 岁 · 预算敏感', color: 'red', focus: '职场妈妈', prompt: '35岁职场妈妈，预算敏感，重视家庭现金流和隐私，时间有限。' },
  { id: 'persona-2', name: '小���', subtitle: '22 岁 · 效率优先', color: 'blue', focus: '设计新人', prompt: '22岁设计新人，刚入职，追求效率，喜欢新工具，但没有记账习惯。' },
]
const replies: Record<string, string[]> = {
  white: ['先等一下，咱们现在知道的是想做财务助手，还不知道人家为什么不记账。是嫌麻烦，还是根本不想看自己花了多少？这俩问题，做出来可不是一个东西。'],
  red: ['���白说的后一个，我有点那个感觉。要是每天打开就告诉我又超支了，我可能第二天就不想点了。帮我省事可以，别一上来就教育我。'],
  black: ['那也不能为了让人舒服就什么都顺着说。账分错了，还一本正经告诉人家这个月能存多少钱，这个错谁兜？我觉得先别急着给储蓄建议。'],
  yellow: ['储蓄建议可以先不做，但小黑这个担心不至于把整个方向否掉吧。光是把账理清楚、少折腾半小时，就可能值得试。咱们先看这个有没有人需要。'],
  green: ['那干脆先别接银行。让人自己挑几笔愿意分享的账，帮他理一遍，再问他明天还想不想用。连这一步都没人愿意，后面的自动化就先别折腾了。'],
  blue: ['小绿这个能先试，��过“愿不愿意分享”和“理完有没有用”得分开看。下一轮先定一个：我们找谁来试，做完什么事才算真的帮到他？'],
}
export const previewMessages: Message[] = hats.map((agent, index) => ({ id: `preview-${agent.id}`, agentId: agent.id, content: replies[agent.id][0], timestamp: 1720000000000 + index * 45000, round: 1, sequence: index + 1, readHostIds: [], targetAgentId: index ? hats[index - 1].id : undefined }))
export function createSummary(topic: string, messages: Message[], agents: Agent[]) {
  const contributions = agents.map(a => ({ agent: a, message: messages.filter(m => m.agentId === a.id).at(-1) })).filter(item => item.message)
  const host = messages.filter(m => m.agentId === 'host').at(-1)
  return { topic, contributions, host, count: messages.filter(m => m.agentId !== 'host').length }
}
export function exportMarkdown(topic: string, messages: Message[], agents: Agent[], includeSummary: boolean, generatedSummary = '', preview = false) {
  const names = Object.fromEntries(agents.map(a => [a.id, a.name]))
  const parts = ['# SynapseRound 讨论纪要', preview ? '> 预设示例，非模型生成，不构成真实用户调研或专业建议。' : '> 由 Step Plan · step-5-preview 生成；模拟观点不构成真实用户调研或专业建议。', `## 议题\n${topic}`, '## 完整讨论', ...messages.map(m => `### ${messageLabel(m)} · ${names[m.agentId] ?? '主持人'}\n${m.content}${m.readHostIds?.length ? `\n已读取主持人介入：${m.readHostIds.map(id => messages.find(item => item.id === id)?.sequence ?? id).join('、')}` : ''}`)]
  if (includeSummary && generatedSummary) parts.push('## 蓝帽总结 · step-5-preview', generatedSummary)
  else if (includeSummary) { const summary = createSummary(topic, messages, agents); parts.push('## 观点摘录（非模型总结）', `共收集 ${summary.count} 条角色发言。`, ...summary.contributions.map(c => `### ${c.agent.name} · ${c.agent.focus}\n${c.message!.content}`), '### 下一步行动\n- 核验讨论中的假设与数据。\n- 招募真实目标用户开展访谈。\n- 用轻量原型验证核心场景。'); if (summary.host) parts.push(`### 主持人关注点\n${summary.host.content}`) }
  return parts.join('\n\n')
}
