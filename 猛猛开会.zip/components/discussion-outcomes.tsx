'use client'

import { useRef, useState } from 'react'
import useSWR from 'swr'
import { BookmarkPlus, History, Lightbulb, BookOpen, Play, Pencil, Check, Trash2, Star, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { FieldGroup, Field, FieldLabel, FieldContent, FieldDescription, FieldError } from '@/components/ui/field'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert'
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty'
import { historyKey, historyRequest, prioritizeInsights, qualifiesForHistory, type Snapshot, type Insight, type HistoryItem } from '@/lib/history'
import type { Message } from '@/lib/discussion'

export function useHistory(snapshot: Snapshot, autosave: boolean) {
  const swr = useSWR(historyKey, () => historyRequest(), { shouldRetryOnError: false, revalidateOnFocus: true })
  const queue = useRef<Promise<unknown>>(Promise.resolve())
  async function save(body: unknown) {
    const pending = queue.current.catch(() => {}).then(() => historyRequest(body))
    queue.current = pending
    const data = await pending
    await swr.mutate(data, false)
    return data
  }
  const serialized = JSON.stringify(snapshot)
  const sync = useSWR(autosave && snapshot.messages.length ? ['history-save', serialized] : null, async ([, value]: [string, string]) => {
    const data = JSON.parse(value) as Snapshot
    return save({ id: data.run.runId, snapshot: data })
  }, { shouldRetryOnError: false, revalidateOnFocus: false, revalidateOnReconnect: false })
  return { ...swr, save, retrySave: () => sync.mutate(), saving: sync.isValidating, saved: !!sync.data, saveError: sync.error?.message ?? '', notes: prioritizeInsights(swr.data?.items.find(item => item.id === snapshot.run.runId)?.notes ?? []) }
}

function SaveError({ message }: { message: string }) {
  return <Alert variant="destructive"><Info /><AlertTitle>记录暂未保存</AlertTitle><AlertDescription>{message}</AlertDescription></Alert>
}

function SourceExcerpt({ note, defaultOpen = false }: { note: Pick<Insight, 'sourceName' | 'sourceRound' | 'sourceSequence' | 'sourceText'>; defaultOpen?: boolean }) {
  if (!note.sourceText) return null
  return <details open={defaultOpen} className="rounded-lg bg-muted p-3 text-sm">
    <summary className="cursor-pointer text-muted-foreground">启发来源 · {note.sourceName || '讨论'}{note.sourceSequence ? ` · 发言 #${note.sourceSequence}` : note.sourceRound ? ` · 历史第 ${note.sourceRound} 轮` : ''}</summary>
    <p className="mt-3 whitespace-pre-wrap break-words leading-relaxed">{note.sourceText}</p>
  </details>
}

export function InsightEditor({ snapshot, source, editing, onClose, onSave }: { snapshot: Snapshot; source?: Message; editing?: Insight; onClose: () => void; onSave: (body: unknown) => Promise<unknown> }) {
  const [conclusion, setConclusion] = useState(editing?.conclusion ?? '')
  const [action, setAction] = useState(editing?.action ?? '')
  const [important, setImportant] = useState(editing?.important ?? false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const name = editing?.sourceName ?? snapshot.run.agents.find(agent => agent.id === source?.agentId)?.name ?? ''
  const text = editing?.sourceText ?? source?.content ?? ''
  async function submit() {
    if (busy) return
    if (!conclusion.trim()) { setError('请写下你从讨论中悟出的结论。'); return }
    setBusy(true); setError('')
    const note: Insight = { id: editing?.id ?? crypto.randomUUID(), conclusion: conclusion.trim(), action: action.trim(), important, done: editing?.done ?? false, sourceId: editing?.sourceId ?? source?.id ?? '', sourceName: name, sourceRound: editing?.sourceRound ?? source?.round ?? 0, sourceSequence: editing?.sourceSequence ?? source?.sequence, sourceText: text, createdAt: editing?.createdAt ?? new Date().toISOString() }
    try { await onSave({ id: snapshot.run.runId, snapshot, note }); onClose() }
    catch (cause) { setError(cause instanceof Error ? cause.message : '保存失败，请重试。') }
    finally { setBusy(false) }
  }
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose() }}>
    <DialogContent className="sm:max-w-xl max-h-[85dvh] overflow-y-auto" showCloseButton={!busy}>
      <DialogHeader><DialogTitle>{editing ? '编辑我的小结' : '留住这一刻的洞察'}</DialogTitle><DialogDescription>不只是收藏回答，而是把启发变成你自己的判断与下一步。</DialogDescription></DialogHeader>
      <SourceExcerpt defaultOpen note={{ sourceName: name, sourceRound: editing?.sourceRound ?? source?.round ?? 0, sourceSequence: editing?.sourceSequence ?? source?.sequence, sourceText: text }} />
      <FieldGroup>
        <Field data-invalid={!!error && !conclusion.trim()} data-disabled={busy}>
          <FieldLabel htmlFor="insight-conclusion">我悟出的结论</FieldLabel>
          <Textarea id="insight-conclusion" value={conclusion} onChange={e => setConclusion(e.target.value)} disabled={busy} rows={3} maxLength={2000} aria-invalid={!!error && !conclusion.trim()} placeholder="例如：找到核心驱动市场的最小变量。" />
          <FieldDescription>用自己的话写下来，区别于角色原文与模型总结。</FieldDescription>
        </Field>
        <Field data-disabled={busy}>
          <FieldLabel htmlFor="insight-action">下一步怎么做（选填）</FieldLabel>
          <Textarea id="insight-action" value={action} onChange={e => setAction(e.target.value)} disabled={busy} rows={3} maxLength={4000} placeholder="例如：列出三个可能的驱动因素，只改变一个变量，用小样本验证。" />
        </Field>
        <Field orientation="horizontal" data-disabled={busy}>
          <FieldContent><FieldLabel htmlFor="insight-important">设为重点洞察</FieldLabel><FieldDescription>在我的小结和历史话题预览中优先展示。</FieldDescription></FieldContent>
          <Switch id="insight-important" checked={important} onCheckedChange={setImportant} disabled={busy} />
        </Field>
        {error && <FieldError>{error}</FieldError>}
      </FieldGroup>
      <DialogFooter><Button variant="outline" disabled={busy} onClick={onClose}>取消</Button><Button disabled={busy || !conclusion.trim()} onClick={() => void submit()}><BookmarkPlus data-icon="inline-start" />{busy ? '正在保存…' : '保存小结'}</Button></DialogFooter>
    </DialogContent>
  </Dialog>
}

function InsightCard({ note, busy, removing, onEdit, onUpdate, onRemove }: { note: Insight; busy: boolean; removing: boolean; onEdit: () => void; onUpdate: (note: Insight) => void; onRemove: (confirmed: boolean) => void }) {
  return <Card>
    <CardHeader>
      <div className="flex flex-wrap items-center gap-2"><Badge variant={note.important ? 'default' : 'secondary'}>{note.important ? <><Star data-icon="inline-start" />重点洞察</> : '我的结论'}</Badge>{note.action && <Badge variant="outline">{note.done ? '行动已完成' : '待行动'}</Badge>}</div>
      <CardTitle className="whitespace-pre-wrap break-words leading-relaxed">{note.conclusion}</CardTitle>
      <CardDescription>手动记录 · {new Date(note.createdAt).toLocaleDateString('zh-CN')} · {note.sourceName || '整场讨论'}{note.sourceSequence ? ` · 发言 #${note.sourceSequence}` : note.sourceRound ? ` · 历史第 ${note.sourceRound} 轮` : ''}</CardDescription>
    </CardHeader>
    <CardContent><div className="flex flex-col gap-4">
      {note.action && <div><Badge variant="secondary">下一步行动</Badge><p className="mt-2 whitespace-pre-wrap break-words leading-relaxed">{note.action}</p></div>}
      <SourceExcerpt note={note} />
    </div></CardContent>
    <CardFooter className="flex flex-wrap justify-between gap-2">
      <div className="flex flex-wrap gap-1">
        <Button variant="ghost" size="sm" disabled={busy} aria-pressed={!!note.important} onClick={() => onUpdate({ ...note, important: !note.important })}><Star data-icon="inline-start" />{note.important ? '取消重点' : '设为重点'}</Button>
        {note.action && <Button variant="ghost" size="sm" disabled={busy} onClick={() => onUpdate({ ...note, done: !note.done })}><Check data-icon="inline-start" />{note.done ? '恢复待行动' : '完成行动'}</Button>}
      </div>
      <div className="flex flex-wrap gap-1">
        {removing ? <><Button variant="outline" size="sm" disabled={busy} onClick={() => onRemove(false)}>保留</Button><Button variant="destructive" size="sm" disabled={busy} onClick={() => onRemove(true)}><Trash2 data-icon="inline-start" />确认删除</Button></> : <><Button variant="ghost" size="sm" disabled={busy} onClick={onEdit}><Pencil data-icon="inline-start" />编辑</Button><Button variant="ghost" size="sm" disabled={busy} onClick={() => onRemove(false)}><Trash2 data-icon="inline-start" />删除</Button></>}
      </div>
    </CardFooter>
  </Card>
}

export function OutcomesView({ notes, onAdd, onEdit, onUpdate, id, error, canAdd, loading }: { notes: Insight[]; onAdd: () => void; onEdit: (note: Insight) => void; onUpdate: (body: unknown) => Promise<unknown>; id: string; error?: string; canAdd: boolean; loading: boolean }) {
  const [failure, setFailure] = useState('')
  const [busy, setBusy] = useState('')
  const [removing, setRemoving] = useState('')
  async function update(body: unknown, noteId: string) {
    if (busy) return
    setBusy(noteId); setFailure('')
    try { await onUpdate(body); setRemoving('') }
    catch (cause) { setFailure(cause instanceof Error ? cause.message : '更新失败，请重试。') }
    finally { setBusy('') }
  }
  return <div className="flex flex-col gap-5 p-4 sm:p-6">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="flex items-center gap-2 text-lg font-semibold"><Lightbulb className="size-5 text-primary" />我的洞察与下一步</h2><p className="mt-1 text-sm text-muted-foreground">讨论不是目的，留下能指导行动的结论。重点洞察排在最前。</p></div><Button variant="outline" disabled={!canAdd} onClick={onAdd}><BookmarkPlus data-icon="inline-start" />记一条小结</Button></div>
    {(error || failure) && <SaveError message={failure || error!} />}
    {loading && <p role="status" className="text-sm text-muted-foreground">正在加载我的小结…</p>}
    {!notes.length && !loading && !error && <Empty className="border"><EmptyHeader><EmptyMedia variant="icon"><Lightbulb /></EmptyMedia><EmptyTitle>留住一个能指导下一步的想法</EmptyTitle><EmptyDescription>{canAdd ? '点击发言卡片上的「记小结」，写下自己的结论与下一步行动，也可以为整场讨论记录小结。' : '先设置一个议题并开始讨论，再记录你的洞察。'}</EmptyDescription></EmptyHeader></Empty>}
    {prioritizeInsights(notes).map(note => <InsightCard key={note.id} note={note} busy={!!busy} removing={removing === note.id} onEdit={() => onEdit(note)} onUpdate={next => void update({ id, note: next }, note.id)} onRemove={confirmed => { if (confirmed) void update({ id, removeNoteId: note.id }, note.id); else setRemoving(removing === note.id ? '' : note.id) }} />)}
  </div>
}

export function HistoryLibrary({ items, error, locked, loading, onOpen, onContinue, onRetry }: { items: HistoryItem[]; error?: string; locked: boolean; loading: boolean; onOpen: (item: HistoryItem) => void; onContinue: (item: HistoryItem) => void; onRetry: () => void }) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const query = search.trim().toLocaleLowerCase()
  const filtered = items.filter(item => qualifiesForHistory(item.snapshot) && [item.snapshot.run.topic, ...item.notes.flatMap(note => [note.conclusion, note.action])].join(' ').toLocaleLowerCase().includes(query))
  return <>
    <Button variant="outline" size="sm" onClick={() => { setOpen(true); onRetry() }}><History data-icon="inline-start" />历史讨论</Button>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="sm:max-w-2xl max-h-[85dvh] overflow-y-auto">
      <DialogHeader><DialogTitle>有价值的讨论，值得再打开</DialogTitle><DialogDescription>可以回看原记录，也可以沿用原议题和角色继续讨论，新发言会接在原记录后并保留小结。回看后可在左侧调整续谈时长。实际推演满 3 分钟才计入历史，暂停时间不计入；记录保存在数据库，当前浏览器可访问，清除 Cookie 或更换浏览器不会自动同步。</DialogDescription></DialogHeader>
      <Input aria-label="搜索历史议题和小结" placeholder="搜索议题、结论或下一步行动…" value={search} onChange={event => setSearch(event.target.value)} />
      {error && <><SaveError message={error} /><Button variant="outline" onClick={onRetry}>重试加载</Button></>}
      {loading && <p role="status" className="text-sm text-muted-foreground">正在加载历史讨论…</p>}
      {locked && <p className="text-sm text-muted-foreground">请先结束当前讨论，再打开历史话题，以免中断推演。</p>}
      {!filtered.length && !error && !loading && <Empty><EmptyHeader><EmptyMedia variant="icon"><History /></EmptyMedia><EmptyTitle>{query ? '没有匹配的讨论' : '还没有历史讨论'}</EmptyTitle><EmptyDescription>{query ? '试试议题、结论或行动中的关键词。' : '实际推演满 3 分钟的讨论会计入历史；未满 3 分钟的讨论不计入。示例讨论在记小结后保存。'}</EmptyDescription></EmptyHeader></Empty>}
      <div className="flex flex-col gap-4">{filtered.map(item => <HistoryCard key={item.id} item={item} locked={locked} onOpen={() => { onOpen(item); setOpen(false) }} onContinue={() => { onContinue(item); setOpen(false) }} />)}</div>
    </DialogContent></Dialog>
  </>
}

function HistoryCard({ item, locked, onOpen, onContinue }: { item: HistoryItem; locked: boolean; onOpen: () => void; onContinue: () => void }) {
  const notes = prioritizeInsights(item.notes)
  return <Card>
    <CardHeader><CardTitle className="line-clamp-2 break-words leading-relaxed">{item.snapshot.run.topic}</CardTitle><CardDescription>{new Date(item.updatedAt).toLocaleString('zh-CN')} · {item.snapshot.messages.length} 条发言 · {notes.length} 条小结{item.snapshot.preview ? ' · 示例讨论' : ''}</CardDescription></CardHeader>
    <CardContent>{notes.length ? <ul className="flex flex-col gap-3">{notes.slice(0, 3).map(note => <li key={note.id} className="flex items-start gap-2 text-sm">{note.important ? <Star className="mt-0.5 size-4 shrink-0 text-primary" /> : <Lightbulb className="mt-0.5 size-4 shrink-0 text-muted-foreground" />}<div className="min-w-0"><p className="break-words">{note.conclusion}</p>{note.action && <p className="mt-1 line-clamp-2 break-words text-muted-foreground">{note.done ? '已完成：' : '下一步：'}{note.action}</p>}</div></li>)}</ul> : <p className="text-sm text-muted-foreground">尚未记录个人洞察</p>}</CardContent>
    <CardFooter className="flex flex-wrap justify-end gap-2"><Button variant="outline" size="sm" disabled={locked} onClick={onOpen}><BookOpen data-icon="inline-start" />回看记录</Button><Button size="sm" disabled={locked} onClick={onContinue}><Play data-icon="inline-start" />继续讨论</Button></CardFooter>
  </Card>
}
