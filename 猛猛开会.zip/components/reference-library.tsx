'use client'

import { useRef, useState } from 'react'
import useSWR from 'swr'
import { BookOpen, FileText, Globe, Upload, ExternalLink, Trash2, ShieldCheck, Info, Search, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel, FieldDescription } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Spinner } from '@/components/ui/spinner'
import { AgentAvatar } from '@/components/discussion-board'
import type { Agent } from '@/lib/discussion'
import { resourceFetcher, resourceKey } from '@/lib/resources'

function RoleSelect({ id, value, onChange, agents, includeAll = true }: { id: string; value: string; onChange: (value: string) => void; agents: Agent[]; includeAll?: boolean }) {
  const items = [...(includeAll ? [{ label: '所有角色 · 共享资料', value: 'all' }] : []), ...agents.map(agent => ({ label: agent.name, value: agent.id }))]
  return <Select items={items} value={value} onValueChange={next => { if (next) onChange(next) }}><SelectTrigger id={id} aria-label={id === 'reference-filter' ? '按角色筛选资料' : id === 'reference-search-role' ? '联网检索角色' : undefined} className="w-full"><SelectValue /></SelectTrigger><SelectContent><SelectGroup>{items.map(item => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectGroup></SelectContent></Select>
}

export function ReferenceLibrary({ agents, runId, topic, locked }: { agents: Agent[]; runId: string; topic: string; locked: boolean }) {
  const { data, error, isLoading, mutate } = useSWR(resourceKey(runId), resourceFetcher, { revalidateOnFocus: false, shouldRetryOnError: false })
  const [open, setOpen] = useState(false)
  const [audience, setAudience] = useState('all')
  const [filter, setFilter] = useState('all')
  const [searchRole, setSearchRole] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [busy, setBusy] = useState<'upload' | 'search' | 'delete' | null>(null)
  const [message, setMessage] = useState('')
  const [actionError, setActionError] = useState('')
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const resources = data?.resources ?? []
  const currentFilter = agents.some(agent => agent.id === filter) ? filter : 'all'
  const filtered = resources.filter(resource => currentFilter === 'all' || resource.agentIds.includes(currentFilter) || !resource.agentIds.length || resource.citedBy.includes(currentFilter))
  const name = (id: string) => id === 'host' ? '蓝帽总结' : agents.find(agent => agent.id === id)?.name ?? '其他角色'
  const citedCount = resources.filter(resource => resource.citedBy.length).length
  const role = agents.find(agent => agent.id === searchRole) ?? agents[0]
  const currentAudience = audience === 'all' || agents.some(agent => agent.id === audience) ? audience : 'all'

  async function action(kind: 'upload' | 'search' | 'delete', operation: () => Promise<Response>, success: string) {
    if (busy) return
    setBusy(kind); setActionError(''); setMessage('')
    try {
      const response = await operation()
      const result = await response.json()
      if (!response.ok) throw new Error(result.error ?? '操作失败，请重试。')
      setMessage(kind === 'search' ? `已收集 ${result.added} 份有真实来源的联网资料。` : success)
      if (kind === 'upload') { setFile(null); if (fileInput.current) fileInput.current.value = '' }
      setConfirmDelete(null)
      await mutate()
    } catch (cause) {
      setActionError(cause instanceof Error ? cause.message : '操作失败，请重试。')
      if (kind === 'search') void mutate()
    } finally { setBusy(null) }
  }
  function upload() {
    if (!file) return
    if (file.size > 4 * 1024 * 1024) { setActionError('单个文件不能超过 4 MB。'); return }
    const form = new FormData()
    form.set('file', file)
    form.set('agentIds', JSON.stringify(currentAudience === 'all' ? [] : [currentAudience]))
    void action('upload', () => fetch('/api/resources', { method: 'POST', body: form }), '资料已私有保存，将在对应角色的下一次发言中提供。')
  }

  return <>
    <Button variant="ghost" size="sm" onClick={() => { setOpen(true); setActionError(''); setMessage('') }} aria-label={`参考资料，共 ${resources.length} 份`} title="查看各角色参考的资料、上传文件"><BookOpen data-icon="inline-start" /><span className="hidden sm:inline">参考资料</span><span className="tab-count">{resources.length}</span></Button>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="sm:max-w-xl max-h-[88dvh] overflow-y-auto">
      <DialogHeader><DialogTitle>参考资料</DialogTitle><DialogDescription>每个观点，都可以有自己的来处。查看各角色的证据，也把你的资料带到桌上。</DialogDescription></DialogHeader>
      <div className="flex items-center justify-between gap-3 rounded-lg bg-muted px-3 py-2 text-xs text-muted-foreground"><span className="flex items-center gap-2"><ShieldCheck className="size-3.5" />私有资料库 · {resources.length} 份资料</span><span>本场讨论引用 {citedCount} 份</span></div>
      <form onSubmit={event => { event.preventDefault(); upload() }} className="rounded-xl border border-dashed p-4">
        <FieldGroup className="gap-3"><Field><FieldLabel htmlFor="reference-file"><Upload className="size-4" />上传你的资料</FieldLabel><Input ref={fileInput} id="reference-file" type="file" accept=".txt,.md,.pdf,.docx" className="sr-only" tabIndex={-1} disabled={!!busy || !data} onChange={event => { setFile(event.target.files?.[0] ?? null); setActionError('') }} /><div className="flex min-w-0 items-center gap-3"><Button type="button" variant="outline" size="sm" disabled={!!busy || !data} onClick={() => fileInput.current?.click()}><FileText data-icon="inline-start" />选择文件</Button><span className="min-w-0 truncate text-xs text-muted-foreground">{file?.name ?? '还没有选择文件'}</span></div><FieldDescription>TXT、Markdown、PDF、DOCX · 每份不超过 4 MB</FieldDescription></Field><Field><FieldLabel htmlFor="reference-audience">交给谁阅读</FieldLabel><RoleSelect id="reference-audience" value={currentAudience} onChange={setAudience} agents={agents} /></Field></FieldGroup>
        <div className="mt-3 flex justify-end"><Button size="sm" type="submit" disabled={!file || !!busy || !data}>{busy === 'upload' ? <Spinner data-icon="inline-start" aria-label="正在上传" /> : <Upload data-icon="inline-start" />}{busy === 'upload' ? '解析并保存…' : '上传资料'}</Button></div>
      </form>
      <div className="flex flex-col gap-3 rounded-xl border p-4"><div className="flex items-center gap-2 text-sm font-medium"><Globe className="size-4" />让不同角色带来不同的证据</div><p className="text-xs leading-relaxed text-muted-foreground">按当前议题和角色立场检索公开文章。由 Perplexity 搜集真实来源，阶跃负责讨论；检索会产生额外 AI 用量。</p><div className="flex items-center gap-2"><div className="min-w-0 flex-1"><RoleSelect id="reference-search-role" value={role?.id ?? ''} onChange={setSearchRole} agents={agents} includeAll={false} /></div><Button size="sm" variant="outline" aria-label="联网搜集资料" disabled={!!busy || !topic.trim() || !role || !data} onClick={() => void action('search', () => fetch('/api/resources/search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ topic, agent: role }) }), '')}>{busy === 'search' ? <Spinner data-icon="inline-start" aria-label="正在检索" /> : <Search data-icon="inline-start" />}{busy === 'search' ? '正在检索…' : '搜集资料'}</Button></div></div>
      {(actionError || error) && <Alert variant="destructive"><Info /><AlertDescription>{actionError || error.message}</AlertDescription></Alert>}
      {message && <p role="status" className="text-sm text-muted-foreground">{message}</p>}
      <div className="flex items-center justify-between gap-3"><h3 className="text-sm font-medium">资料与引用</h3><div className="flex items-center gap-2"><RoleSelect id="reference-filter" value={agents.some(agent => agent.id === filter) ? filter : 'all'} onChange={setFilter} agents={agents} /><Button variant="ghost" size="icon-sm" aria-label="刷新资料" disabled={!!busy || isLoading} onClick={() => void mutate()}><RefreshCw /></Button></div></div>
      {isLoading ? <div role="status" className="flex justify-center gap-2 p-6 text-sm text-muted-foreground"><Spinner aria-label="正在读取资料" />读取资料中…</div> : !filtered.length ? <Empty><EmptyHeader><EmptyMedia variant="icon"><BookOpen /></EmptyMedia><EmptyTitle>{resources.length ? '这个角色还没有资料' : '先给这场讨论一点依据'}</EmptyTitle><EmptyDescription>上传一份文件，或按某顶帽子的关注方向搜集文章。示例讨论不含真实引用。</EmptyDescription></EmptyHeader></Empty> : <ul className="flex flex-col gap-2">{filtered.map(resource => <li key={resource.id} className="min-w-0 rounded-lg border p-3"><div className="flex items-start gap-3"><div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">{resource.kind === 'web' ? <Globe className="size-4" /> : <FileText className="size-4" />}</div><div className="flex min-w-0 flex-1 flex-col gap-1.5"><a className="flex items-start gap-1 text-sm font-medium hover:underline break-all" href={resource.url ?? `/api/resources/file?id=${resource.id}`} target={resource.url ? '_blank' : undefined} rel={resource.url ? 'noopener noreferrer' : undefined}>{resource.title}{resource.url && <ExternalLink className="mt-0.5 size-3 shrink-0" />}</a><div className="flex flex-wrap items-center gap-2"><Badge variant="outline">{resource.kind === 'web' ? '联网文章 · 检索摘要' : '上传资料'}{resource.truncated ? ' · 已节选' : ''}</Badge><span className="text-xs text-muted-foreground">{resource.kind === 'web' && resource.url ? new URL(resource.url).hostname : `${Math.max(1, Math.round((resource.size ?? 0) / 1024))} KB`}</span></div><p className="text-xs text-muted-foreground">分配给：{resource.agentIds.length ? resource.agentIds.map(name).join('、') : '所有角色'}</p>{resource.citedBy.length ? <div className="flex flex-wrap items-center gap-1.5"><span className="text-xs text-muted-foreground">发言引用</span>{resource.citedBy.map(id => { const agent = agents.find(item => item.id === id); return <span key={id} className="flex items-center gap-1 text-xs">{agent && <AgentAvatar agent={agent} small />}{name(id)}</span> })}</div> : <p className="text-xs text-muted-foreground">{resource.providedTo.length ? `已提供给 ${resource.providedTo.map(name).join('、')} · 尚未标注引用` : '尚未用于本场讨论'}</p>}<details className="text-xs text-muted-foreground"><summary className="cursor-pointer py-1">查看文字节选</summary>{resource.citations.length > 0 && <p className="my-2">引用位置：{resource.citations.map(citation => `${name(citation.agentId)} · 第 ${citation.round} 轮 · [资料${citation.number}]`).join('；')}</p>}<p className="mt-2 whitespace-pre-wrap break-words leading-relaxed">{resource.preview}</p></details></div><Button size="icon-sm" variant="ghost" aria-label={`移除 ${resource.title}`} disabled={!!busy || locked} title={locked ? '讨论结束后可移除' : '移除资料'} onClick={() => setConfirmDelete(resource.id)}><Trash2 /></Button></div>{confirmDelete === resource.id && <div className="mt-3 flex flex-wrap items-center justify-end gap-2 border-t pt-3"><span className="mr-auto text-xs text-muted-foreground">从资料库永久移除？</span><Button variant="ghost" size="sm" onClick={() => setConfirmDelete(null)} disabled={!!busy}>取消</Button><Button variant="destructive" size="sm" disabled={!!busy || locked} onClick={() => void action('delete', () => fetch(`/api/resources?id=${resource.id}`, { method: 'DELETE' }), '已移除资料。')}>{busy === 'delete' ? '移除中…' : '确认移除'}</Button></div>}</li>)}</ul>}
      <p className="border-t pt-3 text-xs leading-relaxed text-muted-foreground">分配不等于引用：仅在发言标注资料编号后记录为「发言引用」，这不保证模型已正确理解。模型按资料数量分配阅读节选，每次合计最多 30,000 字。资料在同一浏览器刷新后保留，新讨论重置引用统计；清除浏览器 Cookie 后无法访问旧资料。上传内容会发送给阶跃用于讨论，请勿包含敏感信息。</p>
    </DialogContent></Dialog>
  </>
}
