'use client'

import { BookOpen, ChevronDown, HatGlasses, Highlighter, UsersRound, FileText, SlidersHorizontal, Info, Play, Pause, Download, Plus, X, RotateCcw, Square, Layers, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Field, FieldGroup, FieldLabel, FieldSet, FieldLegend } from '@/components/ui/field'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { type Agent, type Mode, type Status } from '@/lib/discussion'
import { AgentAvatar } from '@/components/discussion-board'

type Props = {
  mode: Mode; setMode: (mode: Mode) => void; topic: string; setTopic: (topic: string) => void;
  agents: Agent[]; selected: string[]; toggleAgent: (id: string) => void; onEditHat: (agent: Agent) => void;
  durationMinutes: number; setDurationMinutes: (minutes: number) => void; maxLength: number; setMaxLength: (length: number) => void;
  status: Status; onStart: () => void; onPause: () => void; onResume: () => void; onStop: () => void; onExport: () => void;
  onTemplate: () => void; onAddPersona: () => void; onRemovePersona: (id: string) => void; onHelp: () => void; hasMessages: boolean; continueHistory: boolean;
}
function SidebarGuide({ onHelp }: { onHelp: () => void }) {
  return <details className="sidebar-guide">
    <summary><span className="sidebar-guide-icon"><BookOpen aria-hidden="true" /></span><span className="sidebar-guide-heading"><strong>新手图解：5 步开始</strong><span>议题 → 伙伴 → 讨论 → 重点 → 总结</span></span><ChevronDown aria-hidden="true" /></summary>
    <div className="sidebar-guide-content">
      <p className="sidebar-guide-intro">跟着这条路线，把一个想法变成下一步。</p>
      <ol className="sidebar-guide-steps">
        <li><span className="sidebar-guide-step-visual"><FileText aria-hidden="true" /><span>1</span></span><div><strong>写下议题</strong><p>说清你想讨论的问题、想法或方案。</p></div></li>
        <li><span className="sidebar-guide-step-visual"><UsersRound aria-hidden="true" /><span>2</span></span><div><strong>选思维伙伴</strong><p>挑思考帽或用户画像，勾选想听的声音。</p></div></li>
        <li><span className="sidebar-guide-step-visual"><Play aria-hidden="true" /><span>3</span></span><div><strong>开始讨论</strong><p>点击底部按钮开始；讨论中可随时输入追问。</p></div></li>
        <li><span className="sidebar-guide-step-visual"><Highlighter aria-hidden="true" /><span>4</span></span><div><strong>划选文字，留下重点</strong><p>选中一段发言，再点「高亮」「打点」或「加粗」。</p></div></li>
        <li><span className="sidebar-guide-step-visual"><Sparkles aria-hidden="true" /><span>5</span></span><div><strong>记小结、看总结</strong><p>保存自己的结论，再查看「蓝帽总结」并导出纪要。</p></div></li>
      </ol>
      <button type="button" className="sidebar-guide-help" onClick={onHelp}><Info aria-hidden="true" />查看完整使用说明</button>
    </div>
  </details>
}
export function ControlPanel(p: Props) {
  const locked = p.status === 'running' || p.status === 'paused'
  return <aside className="control-panel"><div className="panel-scroll"><div className="panel-heading"><span className="section-eyebrow">讨论设置</span><SlidersHorizontal className="size-4" /></div>
    <Tabs value={p.mode} onValueChange={value => p.setMode(value as Mode)} className="mode-tabs"><TabsList className="w-full"><TabsTrigger value="hats" disabled={locked}><HatGlasses />六顶思考帽</TabsTrigger><TabsTrigger value="personas" disabled={locked}><UsersRound />访谈模拟</TabsTrigger></TabsList></Tabs>
    <SidebarGuide onHelp={p.onHelp} />
    <FieldGroup className="gap-6"><Field data-disabled={locked}><div className="label-line"><FieldLabel htmlFor="discussion-topic"><FileText className="size-4" />讨论议题</FieldLabel><button disabled={locked} className="text-action" onClick={p.onTemplate}>使用模板 <Layers className="size-3" /></button></div><Textarea id="discussion-topic" value={p.topic} onChange={e => p.setTopic(e.target.value)} maxLength={2000} disabled={locked} placeholder="描述你的产品想法、设计方案，或一个待验证的假设…" className="topic-input" /><div className="field-caption"><span>给出背景，让讨论更有深度</span><span>{p.topic.length}/2000</span></div></Field>
    <Separator />
    <FieldSet className="agent-fieldset"><FieldLegend variant="label"><span className="label-line"><span className="flex items-center gap-2"><UsersRound className="size-4" />{p.mode === 'hats' ? '参与员工' : '用户画像'}</span><span className="muted-count">{p.selected.length} 位已启用</span></span></FieldLegend><FieldGroup className="gap-3.5">{p.agents.map(agent => <Field key={agent.id} orientation="horizontal" data-disabled={locked} className="agent-setting"><AgentAvatar agent={agent} small /><FieldLabel htmlFor={`enable-${agent.id}`} className="agent-label"><strong>{agent.name}</strong><span>{agent.subtitle}</span></FieldLabel>{p.mode === 'hats' && <Button variant="ghost" size="xs" disabled={locked} onClick={() => p.onEditHat(agent)} aria-label={`编辑${agent.name}人设`} title="编辑人设提示词">人设</Button>}<Switch id={`enable-${agent.id}`} aria-label={`启用${agent.name}`} checked={p.selected.includes(agent.id)} onCheckedChange={() => p.toggleAgent(agent.id)} disabled={locked} />{p.mode === 'personas' && <button className="remove-persona" onClick={() => p.onRemovePersona(agent.id)} disabled={locked} aria-label={`移除${agent.name}`}><X className="size-3" /></button>}</Field>)}</FieldGroup>{p.mode === 'personas' && <Button variant="outline" onClick={p.onAddPersona} disabled={locked || p.agents.length >= 4} className="w-full mt-3"><Plus data-icon="inline-start" />添加画像（最多 4 位）</Button>}</FieldSet>
    <Separator />
    <FieldSet className="parameter-fieldset"><FieldLegend variant="label"><span className="flex items-center gap-2"><SlidersHorizontal className="size-4" />推演参数</span></FieldLegend><FieldGroup className="gap-5"><Field data-disabled={locked}><div className="label-line"><FieldLabel htmlFor="duration">{p.continueHistory ? '续谈时长' : '讨论时长'}</FieldLabel><Badge variant="secondary">{p.durationMinutes} 分钟</Badge></div><Slider id="duration" aria-label={p.continueHistory ? '续谈时长（分钟）' : '讨论时长（分钟）'} value={[p.durationMinutes]} onValueChange={value => p.setDurationMinutes(Array.isArray(value) ? value[0] : value)} min={1} max={30} step={1} disabled={locked} /><div className="slider-caption">{p.continueHistory ? <><span>追加 1 分钟</span><span>追加 30 分钟</span></> : <><span>1 分钟 · 快速碰撞</span><span>30 分钟 · 深入探索</span></>}</div><p className="text-xs text-muted-foreground">{p.continueHistory ? '会保留原有发言和小结，新观点接在原记录后。' : '自由接话，不限轮次。暂停时计时停止；到时完成当前发言，不再开启下一条。'}</p></Field><Field data-disabled={locked}><div className="label-line"><FieldLabel htmlFor="max-length">每次发言上限</FieldLabel><span className="length-input"><input id="max-length" aria-label="每次发言字数上限" type="number" value={p.maxLength} min={100} max={600} step={50} disabled={locked} onChange={e => p.setMaxLength(Math.max(100, Math.min(600, Number(e.target.value))))} /><span>字</span></span></div></Field></FieldGroup></FieldSet>
    </FieldGroup>
    <div className="panel-tip"><Info className="size-4" /><p>好的讨论，从不同的声音开始。<br />随时插话，为思考带来新方向。</p></div>
  </div><div className="control-footer">{p.status === 'running' ? <div className="flex gap-2"><Button size="lg" className="flex-1" onClick={p.onPause}><Pause data-icon="inline-start" />暂停讨论</Button><Button size="icon-lg" variant="outline" aria-label="中止讨论" onClick={p.onStop}><Square /></Button></div> : p.status === 'paused' ? <div className="flex gap-2"><Button size="lg" className="flex-1" onClick={p.onResume}><Play data-icon="inline-start" />继续推演</Button><Button size="icon-lg" variant="outline" aria-label="中止讨论" onClick={p.onStop}><Square /></Button></div> : <Button size="lg" onClick={p.onStart} disabled={!p.topic.trim() || !p.selected.length} className="w-full start-button">{p.continueHistory || p.status === 'ready' ? <Play data-icon="inline-start" /> : <RotateCcw data-icon="inline-start" />}{p.continueHistory ? '继续历史讨论' : p.status === 'ready' ? '开始讨论' : '重新开始讨论'}<span className="button-shortcut">↗</span></Button>}<Button variant="ghost" className="w-full export-button" onClick={p.onExport} disabled={!p.hasMessages}><Download data-icon="inline-start" />导出 Markdown</Button><p className="demo-footnote"><span />step-5-preview · 已保存讨论可在历史中打开</p></div></aside>
}
