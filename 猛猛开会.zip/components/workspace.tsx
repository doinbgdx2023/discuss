'use client'

import { useRef, useState } from 'react'
import { HistoryLibrary, InsightEditor, OutcomesView, useHistory } from '@/components/discussion-outcomes'
import { exportInsights, qualifiesForHistory, type Snapshot, type Insight, type HistoryItem } from '@/lib/history'
import { Network, PanelsTopLeft, CircleHelp, Sun, Moon, ChevronDown, ChevronRight, Plus, ArrowUpRight, LayoutGrid, List, Sparkles, Download, MoreHorizontal, UserRound, ArrowUp, MessageSquare, Info, X, Check, WandSparkles, Lightbulb, Settings2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel, FieldError } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { InputGroup, InputGroupAddon, InputGroupInput } from '@/components/ui/input-group'
import { ControlPanel } from '@/components/control-panel'
import { HatPromptEditor } from '@/components/hat-prompt-editor'
import { ReferenceLibrary } from '@/components/reference-library'
import useSWR from 'swr'
import { exportResources, resourceFetcher, resourceKey } from '@/lib/resources'
import { AgentAvatar, DiscussionBoard, DiscussionTimeline, SummaryView } from '@/components/discussion-board'
import { useDiscussion } from '@/hooks/use-discussion'
import { type Agent, type Mode, type Message, type MessageMark, defaultTopic, defaultPersonas, hats, exportMarkdown, formatDuration } from '@/lib/discussion'
import { cn } from '@/lib/utils'

const templates = [
  { title: 'AI 财务助手', tag: '产品方向验证', description: '从用户需求、信任与商业价值审视你的产品想法。', topic: defaultTopic },
  { title: '新用户引导体验', tag: 'UX 设计评审', description: '找到首次体验中的认知负担与流失风险。', topic: '我们想把 SaaS 产品的新用户引导从 5 步缩减为 2 步，只保留目标选择和首个任务创建。请评估这对新用户理解、激活和长期留存的影响。' },
  { title: '会员订阅方案', tag: '商业假设测试', description: '探索用户的付费动机、顾虑与期待。', topic: '我们准备为一款效率工具推出每月 29 元的会员订阅，包括 AI 辅助、无限项目和数据导出。目标用户是自由职业者。如何验证付费意愿并降低试用门槛？' },
]
export function Workspace() {
  const discussion = useDiscussion()
  const { data: referenceData } = useSWR(resourceKey(discussion.run.runId), resourceFetcher, { revalidateOnFocus: false, shouldRetryOnError: false })
  const [mode, setMode] = useState<Mode>('hats')
  const [topic, setTopic] = useState(defaultTopic)
  const [personas, setPersonas] = useState(defaultPersonas)
  const [hatAgents, setHatAgents] = useState(hats)
  const [editingHat, setEditingHat] = useState<Agent | null>(null)
  const [selected, setSelected] = useState(hats.map(a => a.id))
  const [durationMinutes, setDurationMinutes] = useState(5)
  const [maxLength, setMaxLength] = useState(300)
  const [view, setView] = useState('board')
  const [tab, setTab] = useState('discussion')
  const [hostInput, setHostInput] = useState('')
  const [dialog, setDialog] = useState<'template' | 'persona' | 'help' | 'new' | null>(null)
  const [personaName, setPersonaName] = useState('')
  const [personaDescription, setPersonaDescription] = useState('')
  const [personaJson, setPersonaJson] = useState('')
  const [personaMethod, setPersonaMethod] = useState('form')
  const [formError, setFormError] = useState('')
  const [dark, setDark] = useState(false)
  const [notice, setNotice] = useState('')
  const [showTip, setShowTip] = useState(true)
  const hostRef = useRef<HTMLInputElement>(null)
  const allAgents = mode === 'hats' ? hatAgents : personas
  const agents = allAgents.filter(a => selected.includes(a.id))
  const locked = discussion.status === 'running' || discussion.status === 'paused'
  const displayAgents = locked || discussion.status === 'completed' || discussion.status === 'stopped' ? discussion.run.agents : agents
  const displayTopic = discussion.isPreview ? defaultTopic : discussion.run.topic || topic
  const isRunning = discussion.status === 'running'
  const activeId = isRunning ? discussion.active?.id : undefined
  const visibleMessages = discussion.messages.filter(m => m.agentId === 'host' || displayAgents.some(a => a.id === m.agentId))
  const title = displayTopic === defaultTopic ? 'AI 财务助手 · 产品方向探索' : displayTopic ? displayTopic.slice(0, 25) + (displayTopic.length > 25 ? '…' : '') : '一次新的思考，正在酝酿'

  const [previewRunId, setPreviewRunId] = useState(() => crypto.randomUUID())
  const [restoredRunId, setRestoredRunId] = useState('')
  const [recording, setRecording] = useState<{ source?: Message; note?: Insight } | null>(null)
  const snapshot: Snapshot = { run: { ...discussion.run, runId: discussion.run.runId || previewRunId, topic: displayTopic, agents: displayAgents }, messages: visibleMessages, summary: discussion.summaryLoading ? '' : discussion.summary, mode, preview: discussion.isPreview }
  const history = useHistory(snapshot, !discussion.isPreview && !!discussion.run.runId && discussion.run.runId !== restoredRunId && !discussion.summaryLoading)
  function applyMessageMark(messageId: string, mark: MessageMark) {
    const result = discussion.toggleMessageMark(messageId, mark)
    if (!result) return
    if (!result.changed) { notify('这条发言的标注已达到上限。'); return }
    if (restoredRunId === snapshot.run.runId) {
      const updatedSnapshot = { ...snapshot, messages: result.messages.filter(message => message.agentId === 'host' || displayAgents.some(agent => agent.id === message.agentId)) }
      void history.save({ id: snapshot.run.runId, snapshot: updatedSnapshot }).then(() => notify(result.added ? '标注已保存到历史讨论。' : '已取消此处的标注，更新已保存。')).catch(cause => notify(cause instanceof Error ? cause.message : '保存标注失败，请重试。'))
    } else if (discussion.isPreview) notify('示例讨论中的标注只保留在当前页面。')
  }
  function openHistory(item: HistoryItem, continueAfterOpen = false) {
    if (locked) return
    const continuationMinutes = Math.max(1, Math.min(30, Math.round((item.snapshot.run.durationSeconds ?? 300) / 60)))
    setRestoredRunId(item.id)
    discussion.restore(item.snapshot)
    setMode(item.snapshot.mode); setTopic(item.snapshot.run.topic)
    if (item.snapshot.mode === 'hats') setHatAgents(item.snapshot.run.agents)
    else setPersonas(item.snapshot.run.agents)
    setSelected(item.snapshot.run.agents.map(agent => agent.id)); setDurationMinutes(continuationMinutes); setMaxLength(item.snapshot.run.maxLength); setHostInput('')
    if (continueAfterOpen) {
      if (!discussion.continueFromHistory(continuationMinutes)) {
        setTab('outcomes'); setNotice('这条历史讨论已达到续谈上限，或没有可继续的发言。'); return
      }
      setRestoredRunId(''); setTab('discussion'); setNotice('已接着历史讨论继续；原有发言和小结都会保留。'); return
    }
    setTab('outcomes'); setNotice('已打开历史话题，先回顾你的洞察与下一步。')
  }
  function notify(text: string) { setNotice(text) }
  function changeMode(value: Mode) { setMode(value); setSelected((value === 'hats' ? hatAgents : personas).map(a => a.id)); discussion.reset(); setRestoredRunId(''); setPreviewRunId(crypto.randomUUID()); setTab('discussion'); setHostInput('') }
  function start() {
    if (restoredRunId && restoredRunId === discussion.run.runId) {
      if (!discussion.continueFromHistory(durationMinutes)) { notify('这条历史��论已达到续谈上限，或没有可继续的发言。'); return }
      setRestoredRunId(''); setHostInput(''); setTab('discussion'); notify('已接着历史讨论继续；原有发言和小结都会保留。'); return
    }
    discussion.start(agents, topic, durationMinutes, maxLength); setRestoredRunId(''); setHostInput(''); setTab('discussion'); setNotice('')
  }
  function pauseForHost() { if (isRunning) { discussion.pause(); notify('已为主持人暂停讨论与计时，发送后点击「继续推演」恢复。') } }
  function sendHost() { if (!hostInput.trim() || !locked) return; if (!discussion.intervene(hostInput)) { notify('当前讨论记录已满，请先结束并导出。'); return }; setHostInput(''); notify('观点已加入讨论。点击「继续推演」，角色将读取并优先回应。') }
  function download() {
    const file = new Blob([exportMarkdown(displayTopic, visibleMessages, displayAgents, true, discussion.summaryLoading ? '' : discussion.summary, discussion.isPreview) + exportInsights(history.notes) + exportResources(referenceData?.resources ?? [], Object.fromEntries([...allAgents, { id: 'host', name: '蓝帽总结' }].map(agent => [agent.id, agent.name])))], { type: 'text/markdown;charset=utf-8' })
    const url = URL.createObjectURL(file); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'SynapseRound-讨论纪要.md'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); notify('讨论纪要已导出，包含完整发言与摘要。')
  }
  function addPersona() {
    setFormError('')
    let items: { name: string; description: string }[] = []
    if (personaMethod === 'json') {
      try { const value = JSON.parse(personaJson); const list = Array.isArray(value) ? value : [value]; if (!list.length || list.some(item => typeof item?.name !== 'string' || typeof item?.description !== 'string' || !item.name.trim() || !item.description.trim())) throw new Error(); items = list }
      catch { setFormError('请输入有效 JSON，每个画像需包含 name 和 description。'); return }
    } else { if (!personaName.trim() || !personaDescription.trim()) { setFormError('请填写画像名称和背景描述。'); return } items = [{ name: personaName, description: personaDescription }] }
    if (items.length + personas.length > 4) { setFormError('最多支持 4 位用户画像，请先移除已有画像。'); return }
    const additions = items.map((item, index) => ({ id: `persona-${crypto.randomUUID()}`, name: item.name.trim().slice(0, 20), subtitle: item.description.slice(0, 16), color: ['green', 'yellow', 'red', 'blue'][(personas.length + index) % 4], focus: '自定义用户', prompt: item.description.trim().slice(0, 1000) }))
    setPersonas(current => [...current, ...additions]); setSelected(current => [...current, ...additions.map(a => a.id)]); setDialog(null); setPersonaName(''); setPersonaDescription(''); setPersonaJson('')
  }
  function newDiscussion() { discussion.reset(); setRestoredRunId(''); setPreviewRunId(crypto.randomUUID()); setTopic(''); setTab('discussion'); setHostInput(''); setDialog(null); setNotice(''); document.getElementById('discussion-topic')?.focus() }
  function toggleTheme() { const next = !dark; setDark(next); document.documentElement.classList.toggle('dark', next); document.documentElement.classList.toggle('light', !next) }
  function focusAgent(agent: Agent) { pauseForHost(); setHostInput(`请${agent.name}进一步说明：`); hostRef.current?.focus(); if (!locked) notify('开始讨论后，即可向角色追问。') }

  return <div className="app-shell" data-ready="true">
    <nav className="navigation-rail" aria-label="主导航"><a href="/" className="brand-mark" aria-label="SynapseRound 首页"><Network /></a><div className="rail-main"><Button variant="ghost" size="icon-lg" className="rail-selected" aria-label="讨论工作台" title="讨论工作台" onClick={() => setTab('discussion')}><PanelsTopLeft /></Button></div><div className="rail-bottom"><Button variant="ghost" size="icon-lg" aria-label="使用指南" title="使用指南" onClick={() => setDialog('help')}><CircleHelp /></Button><Button variant="ghost" size="icon-lg" aria-label="切换深浅色主题" title="切换深浅色主题" onClick={toggleTheme}>{dark ? <Sun /> : <Moon />}</Button><span className="profile-avatar" title="本地step-5-preview">S</span></div></nav>
    <div className="app-body"><header className="global-header"><div className="brand-wordmark">SynapseRound<span className="beta-tag">BETA</span></div><div className="header-breadcrumb"><span>我的工作空间</span><ChevronRight /><strong>思维工作台</strong></div><div className="header-actions"><HistoryLibrary items={history.data?.items ?? []} error={history.error?.message} locked={locked} loading={history.isLoading || history.isValidating} onOpen={openHistory} onContinue={item => openHistory(item, true)} onRetry={() => void history.mutate()} /><Badge variant="outline"><span className="status-dot" />step-5-preview</Badge><Button variant="ghost" size="sm" onClick={() => setDialog('help')}><CircleHelp data-icon="inline-start" />使用指南<ArrowUpRight data-icon="inline-end" /></Button></div></header>
      <div className="workspace-layout"><ControlPanel onHelp={() => setDialog('help')} continueHistory={!!restoredRunId && restoredRunId === discussion.run.runId} mode={mode} setMode={changeMode} topic={topic} setTopic={setTopic} agents={allAgents} onEditHat={setEditingHat} selected={selected} toggleAgent={id => setSelected(current => current.includes(id) ? current.filter(a => a !== id) : [...current, id])} durationMinutes={durationMinutes} setDurationMinutes={setDurationMinutes} maxLength={maxLength} setMaxLength={setMaxLength} status={discussion.status} onStart={start} onPause={discussion.pause} onResume={discussion.resume} onStop={discussion.stop} onExport={download} onTemplate={() => setDialog('template')} onAddPersona={() => { setDialog('persona'); setFormError('') }} onRemovePersona={id => { setPersonas(current => current.filter(a => a.id !== id)); setSelected(current => current.filter(a => a !== id)) }} hasMessages={!!visibleMessages.length} />
        <main className="main-workspace"><section className="workspace-intro"><div><div className="intro-eyebrow"><span />让想法相遇，让可能发生</div><h1>多一个视角，多一种可能<span className="title-period">.</span></h1><p>把想法交给不同的思维角色，在观点碰撞中找到更好的答案。</p></div><Button variant="outline" onClick={() => visibleMessages.length || locked ? setDialog('new') : newDiscussion()}><Plus data-icon="inline-start" />新建讨论</Button></section>
          <section className="session-section"><div className="session-top"><div className="session-title"><span className="session-icon"><MessageSquare /></span><div><h2>{title}</h2><div className="session-meta"><span>{mode === 'hats' ? '六顶思考帽' : '用户画像模拟'}</span><span className="meta-dot">·</span><span>{displayAgents.length} 位思维伙伴</span><span className="meta-dot">·</span><span>{discussion.isPreview ? '示例讨论 · 非模型生成' : 'step-5-preview · 实时推演'}</span></div></div></div><div className="session-avatars">{displayAgents.map(agent => <AgentAvatar key={agent.id} agent={agent} small />)}<span className="avatar-count">+{displayAgents.length}</span></div></div>
            <div className="session-status"><div className="flex items-center gap-2"><span className={cn('status-dot', isRunning && 'pulsing')} /><span>{discussion.status === 'running' ? discussion.remainingSeconds <= 0 ? discussion.active ? '时间已到 · 完成当前发言后结束' : '时间已到 · 正在结束讨论' : discussion.active ? `${discussion.active.name}正在接话…` : '正在根据讨论内容选择下一位…' : discussion.status === 'paused' ? '已暂停 · 等待你的引导' : discussion.status === 'completed' ? '讨论已完成' : discussion.status === 'stopped' ? '讨论已中止' : discussion.isPreview ? '示例已就绪，开启你的第一场讨论' : '准备就绪，等待开始'}</span></div><div className="round-status"><span>{discussion.isPreview || discussion.status === 'ready' ? '限时自由讨论' : '剩余'} <strong>{formatDuration(discussion.isPreview || discussion.status === 'ready' ? durationMinutes * 60 : discussion.remainingSeconds)}</strong>{discussion.status === 'paused' ? ' · 计时已���停' : ''}</span><div className="mini-progress"><span style={{ width: `${discussion.progress}%` }} /></div></div></div>
          </section>
          {discussion.error && <div className="host-note" role="alert"><Info className="size-4" /><span>{discussion.error} 点击「继续推演」重试当前角色。</span></div>}
          {history.saveError && <div className="host-note" role="alert"><Info className="size-4" /><span>{history.saveError}</span><Button variant="ghost" size="sm" onClick={() => void history.retrySave().catch(() => {})}>重试保存</Button></div>}
          {!discussion.isPreview && discussion.messages.length > 0 && !history.saveError && <p role="status" className="px-1 text-xs text-muted-foreground">{discussion.run.runId === restoredRunId ? '正在回顾已保存的历史讨论' : !qualifiesForHistory(snapshot) ? discussion.status === 'stopped' || discussion.status === 'completed' ? '推演不足 3 分钟，不计入历史；当前发言和小结仍可查看、导出。' : '实际推演满 3 分钟后计入历史（暂停时间不计入）。' : history.saving ? '正在保存历史讨论…' : history.saved ? '已保存到历���讨论' : '等待保存…'}</p>}
          <Tabs value={tab} onValueChange={value => setTab(value as string)} className="workspace-tabs"><div className="view-toolbar"><TabsList variant="line"><TabsTrigger value="discussion"><MessageSquare />讨论空间 <span className="tab-count">{visibleMessages.filter(m => m.agentId !== 'host').length}</span></TabsTrigger><TabsTrigger value="outcomes"><Lightbulb />我的小结 <span className="tab-count">{history.notes.length}</span></TabsTrigger><TabsTrigger value="summary"><Sparkles />蓝帽总结</TabsTrigger></TabsList><div className="view-options"><ReferenceLibrary agents={allAgents} runId={discussion.run.runId} topic={discussion.isPreview ? topic : displayTopic} locked={locked} />{tab === 'discussion' && <ToggleGroup value={[view]} onValueChange={values => { if (values.length) setView(values[0]) }} spacing={0} className="view-toggle"><ToggleGroupItem value="board" aria-label="看板视图"><LayoutGrid />看板</ToggleGroupItem><ToggleGroupItem value="timeline" aria-label="时间流视图"><List />时间流</ToggleGroupItem></ToggleGroup>}<Button variant="ghost" size="icon-sm" aria-label="导出讨论纪要" title="导出讨论纪要" onClick={download} disabled={!visibleMessages.length}><Download /></Button></div></div>
            <div className="discussion-canvas" role="tabpanel" aria-label={tab === 'discussion' ? '讨论空间' : tab === 'outcomes' ? '我的小结' : '蓝帽总结'}>{tab === 'outcomes' ? <OutcomesView key={snapshot.run.runId} notes={history.notes} id={snapshot.run.runId} canAdd={!!displayTopic.trim() && visibleMessages.length > 0} loading={history.isLoading} error={history.error?.message} onAdd={() => setRecording({})} onEdit={note => setRecording({ note })} onUpdate={history.save} /> : tab === 'summary' ? <SummaryView topic={displayTopic} messages={visibleMessages} agents={displayAgents} preview={discussion.isPreview} summary={discussion.summary} loading={discussion.summaryLoading} error={discussion.summaryError} onGenerate={() => { setRestoredRunId(''); void discussion.generateSummary() }} canGenerate={!isRunning && visibleMessages.some(message => message.agentId !== 'host')} onMark={applyMessageMark} /> : view === 'board' ? <DiscussionBoard agents={displayAgents} messages={visibleMessages} activeId={activeId} draft={discussion.draft} speaking={discussion.speaking} preview={discussion.isPreview} notes={history.notes} onFocus={focusAgent} onRecord={source => setRecording({ source })} onMark={applyMessageMark} /> : <DiscussionTimeline agents={displayAgents} messages={visibleMessages} activeId={activeId} draft={discussion.draft} speaking={discussion.speaking} notes={history.notes} onRecord={source => setRecording({ source })} onMark={applyMessageMark} />}</div>
          </Tabs>
          <footer className="host-composer-area">{showTip && <div className="host-guidance"><Lightbulb className="size-3.5" /><span>你是这场讨论的主持人。一个好问题，能让讨论走得更远。</span><button aria-label="隐藏提示" onClick={() => setShowTip(false)}><X className="size-3" /></button></div>}<form onSubmit={event => { event.preventDefault(); sendHost() }}><InputGroup className="host-composer"><InputGroupAddon><span className="composer-avatar"><UserRound className="size-4" /></span></InputGroupAddon><InputGroupInput ref={hostRef} aria-label="主持人引导" value={hostInput} onFocus={pauseForHost} onChange={e => { pauseForHost(); setHostInput(e.target.value) }} maxLength={1000} placeholder={locked ? '插入你的追问、补充背景，或引导讨论方向…' : '开始讨论后，随时插入你的追问或引导…'} onKeyDown={event => { if (event.key === 'Enter' && (event.nativeEvent.isComposing || event.keyCode === 229)) event.preventDefault() }} /><InputGroupAddon align="inline-end"><span className="composer-label">主持人</span><Button type="submit" size="icon" disabled={!hostInput.trim() || !locked} aria-label="发送主持人引导"><ArrowUp /></Button></InputGroupAddon></InputGroup></form><div className="composer-caption"><span><span className="keyboard-key">↵</span> 发送引导 · 点击输入框自动暂停，发送后手动继续</span><span>模拟观点仅供启发，不替代真实用户研究 <Info className="size-3" /></span></div></footer>
        </main>
      </div>
    </div>
    {recording && <InsightEditor snapshot={snapshot} source={recording.source} editing={recording.note} onClose={() => setRecording(null)} onSave={async body => { await history.save(body); notify('小结已保存，历史话题将优先展示你的洞察。') }} />}
    {editingHat && <HatPromptEditor key={editingHat.id} agent={editingHat} onClose={() => setEditingHat(null)} onSave={prompt => { if (locked) return; setHatAgents(current => current.map(agent => agent.id === editingHat.id ? { ...agent, prompt } : agent)); setEditingHat(null); notify(`${editingHat.name}人设已应用，下次开始讨论时生效。`) }} />}
    {notice && <div className="notice" role="status"><Check className="size-4" />{notice}<button aria-label="关闭通知" onClick={() => setNotice('')}><X className="size-4" /></button></div>}
    <Dialog open={dialog !== null} onOpenChange={open => { if (!open) setDialog(null) }}><DialogContent className="workspace-dialog sm:max-w-lg">
      {dialog === 'template' && <><DialogHeader><DialogTitle>从一个好议题开始</DialogTitle><DialogDescription>选取模板作为起点，再根据你的项目调整背景。</DialogDescription></DialogHeader><div className="template-list">{templates.map(template => <button key={template.title} disabled={locked} onClick={() => { setTopic(template.topic); setDialog(null); if (!discussion.isPreview) discussion.reset() }}><div><Badge variant="secondary">{template.tag}</Badge><h3>{template.title}</h3><p>{template.description}</p></div><ArrowUpRight className="size-5" /></button>)}</div></>}
      {dialog === 'persona' && <><DialogHeader><DialogTitle>添加目标用户画像</DialogTitle><DialogDescription>补充用户的背景、目标与顾虑，让不同声音参与讨论。</DialogDescription></DialogHeader><Tabs value={personaMethod} onValueChange={value => setPersonaMethod(value as string)}><TabsList><TabsTrigger value="form">简单表单</TabsTrigger><TabsTrigger value="json">JSON 配置</TabsTrigger></TabsList></Tabs><FieldGroup>{personaMethod === 'form' ? <><Field><FieldLabel htmlFor="persona-name">画像名称</FieldLabel><Input id="persona-name" value={personaName} onChange={e => setPersonaName(e.target.value)} maxLength={20} placeholder="例如：张先生" /></Field><Field><FieldLabel htmlFor="persona-description">背景与行为特征</FieldLabel><Textarea id="persona-description" value={personaDescription} onChange={e => setPersonaDescription(e.target.value)} maxLength={1000} placeholder="例如：28 岁自由职业者，收入不稳定，重视隐私，希望减少财务管理的时间。" rows={4} /></Field></> : <Field><FieldLabel htmlFor="persona-json">画像 JSON（对象或数组）</FieldLabel><Textarea id="persona-json" value={personaJson} onChange={e => setPersonaJson(e.target.value)} maxLength={6000} rows={7} placeholder={'[{"name":"张先生","description":"28 岁自由职业者，重视隐私"}]'} /></Field>}{formError && <FieldError>{formError}</FieldError>}</FieldGroup><DialogFooter><Button variant="outline" onClick={() => setDialog(null)}>取消</Button><Button onClick={addPersona}><Plus data-icon="inline-start" />添加画像</Button></DialogFooter></>}
      {dialog === 'help' && <><DialogHeader><DialogTitle>让一场好讨论发生</DialogTitle><DialogDescription>SynapseRound 多角色思维风暴工作台</DialogDescription></DialogHeader><ol className="help-steps"><li><span>01</span><div><strong>设定一个清晰的议题</strong><p>提供产品背景、目标用户与需要验证的假设。</p></div></li><li><span>02</span><div><strong>让不同的声音参与</strong><p>使用六顶思考帽审视方案，或添加 1–4 位目标用户画像。</p></div></li><li><span>03</span><div><strong>随时引导，再收敛行动</strong><p>暂停、插话或追��，在总结中回顾观点，导出 Markdown 纪要。</p></div></li></ol><div className="help-disclaimer"><Info className="size-4" /><p>开始讨论后，将通过服务端调用 Step Plan 的 step-5-preview，消耗套餐 Credit。议题、角色背景和讨论记录会发送给阶跃服务，请勿输入敏感数据。点击主持人输入框会暂停讨论与计时，并取消未完成的生成；发送后点击「继续推演」，角色将根据最新上下文重新接话。完整发言与完成的总结自动保存到 Neon；可在发言卡片点击「记小结」，手动提炼洞察与下一步。重新打开历史话题时优先展示个人小结，再回看讨论原文。参考资料保存在私有 Blob。历史与资料通过浏览器私有 Cookie 隔离，同一浏览器刷新后可在「历史讨论」打开；清除 Cookie 后会失去访问权限。历史快照不会自动恢复未完成的推演。可上传文件或使用 Perplexity 联网搜集文章，联网检索产生额外 AI 用量。模拟画像不能替代真实用户访谈。</p></div></>}
      {dialog === 'new' && <><DialogHeader><DialogTitle>开启一场新的讨论？</DialogTitle><DialogDescription>当前页面将切换到新议题。已保存的讨论与小结仍可从「历史讨论」打开；请确认保存成功，或先导出纪要。</DialogDescription></DialogHeader><DialogFooter><Button variant="outline" onClick={download} disabled={!visibleMessages.length}><Download data-icon="inline-start" />先导出纪要</Button><Button onClick={newDiscussion}>新建讨论</Button></DialogFooter></>}
    </DialogContent></Dialog>
  </div>
}
