'use client'

import { type CSSProperties, type ReactNode, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/utils'
import { ArrowUpRight, Bold, Check, CircleDashed, CircleDot, CornerDownRight, HatGlasses, Highlighter, MessageSquare, Sparkles, UserRound } from 'lucide-react'
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter, CardAction } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { type Agent, type Message, type MessageMark, createSummary, messageLabel, insertDiscussionTurn } from '@/lib/discussion'
import type { Insight } from '@/lib/history'

function RecordedInsights({ messageId, notes }: { messageId: string; notes: Insight[] }) {
  const recorded = notes.filter(note => note.sourceId === messageId)
  if (!recorded.length) return null
  return <Badge variant={recorded.some(note => note.important) ? 'default' : 'secondary'}>{recorded.some(note => note.important) ? '含重点洞察 · ' : ''}已记 {recorded.length} 条小结</Badge>
}

function InlineInsights({ messageId, notes }: { messageId: string; notes: Insight[] }) {
  const recorded = notes.filter(note => note.sourceId === messageId)
  if (!recorded.length) return null
  return <div className="flow-insights" role="region" aria-label="已记录的小结" tabIndex={0}>{recorded.map(note => <div className="flow-insight" data-important={!!note.important} key={note.id}><p><mark>{note.important && <strong>重点 · </strong>}{note.conclusion}</mark></p>{note.action && <p className="flow-insight-action">下一步：{note.action}</p>}</div>)}</div>
}

export function AgentAvatar({ agent, small = false }: { agent: Agent; small?: boolean }) {
  return <span className={`agent-avatar ${small ? 'small' : ''}`} data-color={agent.color}>{agent.id.startsWith('persona') ? <UserRound /> : <HatGlasses />}</span>
}
function visibleTextLength(value: string) {
  return value.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).reduce((length, part) => length + (part.startsWith('**') && part.endsWith('**') ? part.slice(2, -2).length : part.startsWith('*') && part.endsWith('*') ? part.slice(1, -1).length : part.length), 0)
}
function renderInlineText(value: string, offset: number, marks: MessageMark[]) {
  let cursor = offset
  return value.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((part, partIndex) => {
    const isBold = part.startsWith('**') && part.endsWith('**')
    const isItalic = !isBold && part.startsWith('*') && part.endsWith('*')
    const text = isBold ? part.slice(2, -2) : isItalic ? part.slice(1, -1) : part
    const tokenStart = cursor
    cursor += text.length
    if (!text) return null

    const boundaries = [0, text.length]
    for (const mark of marks) {
      if (mark.start > tokenStart && mark.start < tokenStart + text.length) boundaries.push(mark.start - tokenStart)
      if (mark.end > tokenStart && mark.end < tokenStart + text.length) boundaries.push(mark.end - tokenStart)
    }
    const points = [...new Set(boundaries)].sort((a, b) => a - b)
    return points.slice(0, -1).map((start, segmentIndex) => {
      const end = points[segmentIndex + 1]
      const absoluteStart = tokenStart + start
      const absoluteEnd = tokenStart + end
      const active = marks.filter(mark => mark.start < absoluteEnd && mark.end > absoluteStart)
      const hasHighlight = active.some(mark => mark.kind === 'highlight')
      const pointMarks = active.filter(mark => mark.kind === 'point')
      const hasBoldMark = active.some(mark => mark.kind === 'bold')
      let content: ReactNode = text.slice(start, end)
      if (isItalic) content = <em>{content}</em>
      if (isBold) content = <strong>{content}</strong>
      if (hasBoldMark) content = <strong className="message-mark-bold">{content}</strong>
      if (pointMarks.length) content = <span className="message-mark-point">{pointMarks.some(mark => mark.start >= absoluteStart && mark.start < absoluteEnd) && <span className="message-point-marker" role="img" aria-label="标注点" />}{content}</span>
      if (hasHighlight) content = <mark className="message-mark-highlight">{content}</mark>
      return <span key={`${partIndex}-${segmentIndex}`}>{content}</span>
    })
  })
}

type ActiveSelection = { start: number; end: number; left: number; top: number; bottom: number; width: number }
function MessageText({ content, marks = [], messageId, onMark }: { content: string; marks?: MessageMark[]; messageId?: string; onMark?: (mark: MessageMark) => void }) {
  const textRef = useRef<HTMLDivElement>(null)
  const [selection, setSelection] = useState<ActiveSelection | null>(null)
  const paragraphs = content.split('\n\n')
  const visibleLength = paragraphs.reduce((length, paragraph, index) => length + visibleTextLength(paragraph) + (index < paragraphs.length - 1 ? 2 : 0), 0)
  const safeMarks = marks.filter(mark => mark.start >= 0 && mark.end > mark.start && mark.start < visibleLength)
  const canAnnotate = !!messageId && !!onMark

  function captureSelection() {
    const root = textRef.current
    const currentSelection = window.getSelection()
    if (!canAnnotate || !root || !currentSelection || currentSelection.isCollapsed || !currentSelection.rangeCount) { setSelection(null); return }
    const range = currentSelection.getRangeAt(0)
    if (!root.contains(range.startContainer) || !root.contains(range.endContainer)) { setSelection(null); return }
    const paragraphElements = Array.from(root.querySelectorAll<HTMLParagraphElement>('[data-message-paragraph]'))
    const paragraphFor = (node: Node) => {
      const element = node.nodeType === Node.ELEMENT_NODE ? node as Element : node.parentElement
      return element?.closest<HTMLParagraphElement>('[data-message-paragraph]') ?? null
    }
    const startParagraph = paragraphFor(range.startContainer)
    const endParagraph = paragraphFor(range.endContainer)
    if (!startParagraph || !endParagraph) { setSelection(null); return }
    const startParagraphIndex = paragraphElements.indexOf(startParagraph)
    const endParagraphIndex = paragraphElements.indexOf(endParagraph)
    if (startParagraphIndex < 0 || endParagraphIndex < startParagraphIndex) { setSelection(null); return }
    const paragraphStarts: number[] = []
    let textOffset = 0
    paragraphElements.forEach((paragraph, index) => {
      paragraphStarts.push(textOffset)
      textOffset += (paragraph.textContent ?? '').length + (index < paragraphElements.length - 1 ? 2 : 0)
    })
    const offsetIn = (paragraph: HTMLParagraphElement, node: Node, offset: number) => {
      if (node !== paragraph && !paragraph.contains(node)) return null
      const localRange = document.createRange()
      localRange.selectNodeContents(paragraph)
      localRange.setEnd(node, offset)
      return localRange.toString().length
    }
    const localStart = offsetIn(startParagraph, range.startContainer, range.startOffset)
    const localEnd = offsetIn(endParagraph, range.endContainer, range.endOffset)
    if (localStart === null || localEnd === null) { setSelection(null); return }
    const start = paragraphStarts[startParagraphIndex] + localStart
    const end = paragraphStarts[endParagraphIndex] + localEnd
    if (end <= start || !currentSelection.toString().trim()) { setSelection(null); return }
    const bounds = range.getBoundingClientRect()
    const fallback = Array.from(range.getClientRects())[0]
    const rect = bounds.width || bounds.height ? bounds : fallback
    if (!rect) { setSelection(null); return }
    setSelection({ start, end, left: rect.left, top: rect.top, bottom: rect.bottom, width: rect.width })
  }

  useEffect(() => {
    if (!selection) return
    const dismiss = (event: PointerEvent) => {
      const target = event.target
      if (!(target instanceof Node) || textRef.current?.contains(target)) return
      if (target instanceof Element && target.closest('[data-message-mark-toolbar]')) return
      setSelection(null)
    }
    const dismissOnScroll = () => setSelection(null)
    document.addEventListener('pointerdown', dismiss)
    document.addEventListener('scroll', dismissOnScroll, true)
    return () => {
      document.removeEventListener('pointerdown', dismiss)
      document.removeEventListener('scroll', dismissOnScroll, true)
    }
  }, [selection])

  function applyMark(kind: MessageMark['kind']) {
    if (!selection || !onMark) return
    onMark({ start: selection.start, end: selection.end, kind })
    window.getSelection()?.removeAllRanges()
    setSelection(null)
  }

  let toolbar: ReactNode = null
  if (selection && onMark && typeof document !== 'undefined') {
    const toolbarWidth = Math.min(260, window.innerWidth - 16)
    const left = Math.max(8, Math.min(selection.left + selection.width / 2 - toolbarWidth / 2, window.innerWidth - toolbarWidth - 8))
    const above = selection.top > 64
    const isMarked = (kind: MessageMark['kind']) => safeMarks.some(mark => mark.start === selection.start && mark.end === selection.end && mark.kind === kind)
    toolbar = createPortal(<div className="message-mark-toolbar" data-message-mark-toolbar role="toolbar" aria-label="选中文字标注" style={{ left, top: above ? selection.top - 8 : selection.bottom + 8, transform: above ? 'translateY(-100%)' : undefined }} onMouseDown={event => event.preventDefault()}>
      <Button type="button" variant={isMarked('highlight') ? 'secondary' : 'ghost'} size="sm" className="message-mark-action" aria-label="高亮选中文字" aria-pressed={isMarked('highlight')} onClick={() => applyMark('highlight')}><Highlighter data-icon="inline-start" />高亮</Button>
      <Button type="button" variant={isMarked('point') ? 'secondary' : 'ghost'} size="sm" className="message-mark-action" aria-label="给选中文字打点" aria-pressed={isMarked('point')} onClick={() => applyMark('point')}><CircleDot data-icon="inline-start" />打点</Button>
      <Button type="button" variant={isMarked('bold') ? 'secondary' : 'ghost'} size="sm" className="message-mark-action" aria-label="加粗选中文字" aria-pressed={isMarked('bold')} onClick={() => applyMark('bold')}><Bold data-icon="inline-start" />加粗</Button>
    </div>, document.body)
  }

  let paragraphOffset = 0
  return <>
    <div ref={textRef} className="message-text" data-message-id={canAnnotate ? messageId : undefined} onMouseDown={() => setSelection(null)} onMouseUp={captureSelection} onKeyUp={captureSelection} onTouchEnd={captureSelection}>
      {paragraphs.map((paragraph, index) => {
        const start = paragraphOffset
        const paragraphLength = visibleTextLength(paragraph)
        paragraphOffset += paragraphLength + (index < paragraphs.length - 1 ? 2 : 0)
        return <p key={index} data-message-paragraph className="whitespace-pre-line">{renderInlineText(paragraph, start, safeMarks)}</p>
      })}
    </div>
    {toolbar}
  </>
}
type Speaking = { agentId: string; sequence: number; startedAt: number; readHostIds: string[]; selectionReason: string }
function withDraft(messages: Message[], speaking: Speaking | null | undefined, draft: string): Message[] {
  return speaking ? insertDiscussionTurn(messages, { id: 'live-draft', ...speaking, content: draft, timestamp: speaking.startedAt, round: 1 }) : messages
}
function ReadStatus({ message, messages }: { message: Message; messages: Message[] }) {
  const hosts = messages.filter(item => item.agentId === 'host')
  if (!hosts.length) return null
  if (message.readHostIds === undefined) return <Badge variant="outline">历史发言 · 未记录阅读状态</Badge>
  const read = hosts.filter(host => message.readHostIds!.includes(host.id))
  const unread = hosts.some(host => !message.readHostIds!.includes(host.id) && host.timestamp >= (message.startedAt ?? message.timestamp))
  return <div className="flex flex-wrap gap-1.5">{read.length > 0 && <Badge variant="secondary" title={read.map(host => `介入 #${hosts.indexOf(host) + 1}：${host.content}`).join('\n')}>已读取介入 {read.map(host => `#${hosts.indexOf(host) + 1}`).join('、')}</Badge>}{unread && <Badge variant="outline">介入前已开始 · 未读取新指令</Badge>}</div>
}
function TurnCard({ agent, message, messages, notes, onFocus, onRecord, onMark }: { agent: Agent; message: Message; messages: Message[]; notes: Insight[]; onFocus: (agent: Agent) => void; onRecord: (message: Message) => void; onMark: (messageId: string, mark: MessageMark) => void }) {
  const live = message.id === 'live-draft'
  const position = messages.findIndex(item => item.id === message.id)
  const hasContext = (position < 0 ? messages : messages.slice(0, position)).length > 0
  const hostCount = message.readHostIds?.length ?? 0
  const unread = messages.some(item => item.agentId === 'host' && message.readHostIds !== undefined && !message.readHostIds.includes(item.id) && item.timestamp >= (message.startedAt ?? message.timestamp))
  return <>
    <Card className={cn('discussion-card flow-card', live && 'typing-card')} data-color={agent.color}>
      <CardHeader><CardTitle><span className="flow-author"><AgentAvatar agent={agent} /><span><strong>{agent.name}</strong><small>{agent.subtitle}</small></span></span></CardTitle><CardDescription className="sr-only">{messageLabel(message)} · {agent.focus}</CardDescription><CardAction><button className="card-action" aria-label={`追问${agent.name}`} title={`追问${agent.name}`} onClick={() => onFocus(agent)}><ArrowUpRight className="size-4" /></button></CardAction></CardHeader>
      <CardContent>
        <div className="flow-context"><span className="flow-dot" /><span>{hasContext ? '综合前文' : agent.focus}</span><span className="flow-context-status">{live ? '正在接话' : '观点记录'}</span></div>
        <div className="flow-excerpt" role="region" aria-label={`${agent.name}的完整发言`} tabIndex={0}>{message.content ? <MessageText content={message.content} marks={message.marks} messageId={!live ? message.id : undefined} onMark={!live ? mark => onMark(message.id, mark) : undefined} /> : <div className="thinking-dots" aria-label="正在生成发言"><i /><i /><i /></div>}</div>
        <div className="flow-reading"><span title={unread ? '此条发言在新指令介入前已经开始，未读取新指令' : hostCount ? `已读取 ${hostCount} 次主持人介入，详情中可查看具体编号` : undefined}>{unread ? '介入前已开始' : hostCount ? `已读 ${hostCount} 次主持人介入` : live ? '上下文已锁定' : '自由接话'}</span>{message.selectionReason && <span className="flow-selection-reason" title={message.selectionReason}>接话缘由</span>}</div>
      </CardContent>
      <CardFooter><Button variant="ghost" size="sm" disabled={live} aria-label={`记录${agent.name}${messageLabel(message)}的小结`} onClick={() => onRecord(message)}><MessageSquare data-icon="inline-start" />记小结</Button><InlineInsights messageId={message.id} notes={notes} /><span className="flow-card-state">{live ? <><span className="flow-dot pulsing" />生成中</> : <><Check />已完成</>}</span></CardFooter>
    </Card>
  </>
}
function HostBoundary({ message, number, inFlight, read }: { message: Message; number: number; inFlight: boolean; read: boolean }) {
  return <Card className="host-boundary"><CardHeader><CardTitle className="flex flex-wrap items-center gap-2"><UserRound className="size-4" />主持人介入 #{number}<Badge variant="secondary">全员必读 · 优先回应</Badge></CardTitle><CardDescription>{message.sequence ? `全局 #${message.sequence} · ` : ''}{new Date(message.timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}{inFlight ? ' · 上方发言已开始，本指令从下一条新发言生效' : read ? ' · 后续新发言已读取本次介入' : ' · 等待下一条新发言读取并优先回应'}</CardDescription></CardHeader><CardContent><MessageText content={message.content} /></CardContent></Card>
}
export function DiscussionBoard({ agents, messages, activeId, draft, speaking, preview, notes, onFocus, onRecord, onMark }: { agents: Agent[]; messages: Message[]; activeId?: string; draft: string; speaking?: Speaking | null; preview: boolean; notes: Insight[]; onFocus: (agent: Agent) => void; onRecord: (message: Message) => void; onMark: (messageId: string, mark: MessageMark) => void }) {
  const entries = withDraft(messages, activeId ? speaking : null, draft)
  const boardRef = useRef<HTMLDivElement>(null)
  const [columns, setColumns] = useState(3)
  useEffect(() => {
    const board = boardRef.current
    if (!board) return
    const observer = new ResizeObserver(([entry]) => setColumns(entry.contentRect.width >= 1000 ? 3 : entry.contentRect.width >= 620 ? 2 : 1))
    observer.observe(board)
    return () => observer.disconnect()
  }, [])
  const segments: { host?: Message; turns: Message[] }[] = [{ turns: [] }]
  for (const message of entries) {
    if (message.agentId === 'host') segments.push({ host: message, turns: [] })
    else segments.at(-1)!.turns.push(message)
  }
  const hosts = messages.filter(message => message.agentId === 'host')
  return <div className="flow-board" ref={boardRef} style={{ '--flow-columns': columns } as CSSProperties}>
    <div className="flow-board-guide"><div><span className="flow-dot" /><strong>沿线阅读</strong><span className="flow-guide-arrow">→</span><span>{columns > 1 ? '逐行折返，按发言先后接续' : '从上至下，按发言先后接续'}</span></div><em>{preview ? '示例讨论' : `${entries.filter(message => message.agentId !== 'host').length} 条发言`} · 选中文字可标注</em></div>
    {segments.map((segment, segmentIndex) => {
      const rows = Array.from({ length: Math.ceil(segment.turns.length / columns) }, (_, rowIndex) => segment.turns.slice(rowIndex * columns, (rowIndex + 1) * columns))
      return <section className="flow-segment" key={segment.host?.id ?? 'opening'} aria-label={segment.host ? `主持人第${segmentIndex}次介入后` : '讨论开场'}>
        {segment.host && <HostBoundary message={segment.host} number={hosts.indexOf(segment.host) + 1} inFlight={!!speaking && !speaking.readHostIds.includes(segment.host.id)} read={entries.some(message => message.readHostIds?.includes(segment.host!.id))} />}
        <div className="snake-rows">{rows.map((row, rowIndex) => {
          const reverse = rowIndex % 2 === 1
          return <ol className="snake-row" style={{ '--row-count': row.length } as CSSProperties} data-reverse={reverse} data-columns={columns} data-continues={rowIndex < rows.length - 1} key={rowIndex} aria-label={`第${rowIndex + 1}行，${reverse && columns > 1 ? '从右向左' : '从左向右'}阅读`}>
            {row.map((message, index) => {
              const agent = agents.find(item => item.id === message.agentId)
              if (!agent) return null
              return <li className="snake-cell" key={message.id} style={{ gridColumn: reverse ? columns - index : index + 1, gridRow: 1 }}>
                <div className="turn-waypoint"><span className="turn-number" data-live={message.id === 'live-draft'}>{message.sequence ? `#${String(message.sequence).padStart(2, '0')}` : `#${String(entries.indexOf(message) + 1).padStart(2, '0')}`}</span>{columns > 1 && <span className="path-arrow" aria-hidden="true">{reverse ? '‹' : '›'}</span>}</div>
                <TurnCard agent={agent} message={message} messages={messages} notes={notes} onFocus={onFocus} onRecord={onRecord} onMark={onMark} />
              </li>
            })}
          </ol>
        })}</div>
        {!segment.turns.length && segmentIndex === segments.length - 1 && <div className="flow-waiting"><CircleDashed className="size-4" /><span>{segment.host ? '等待下一条发言 · 将优先回应主持人' : '等待讨论开始 · 新发言将沿路径排列'}</span></div>}
      </section>
    })}
    <div className="flow-end"><span className="flow-dot" /><span>{activeId ? '讨论正在延伸' : preview ? '示例阅读到这里' : '当前记录到这里'}</span></div>
  </div>
}
export function DiscussionTimeline({ agents, messages, activeId, draft, speaking, notes, onRecord, onMark }: { agents: Agent[]; messages: Message[]; activeId?: string; draft: string; speaking?: Speaking | null; notes: Insight[]; onRecord: (message: Message) => void; onMark: (messageId: string, mark: MessageMark) => void }) {
  const entries = withDraft(messages, activeId ? speaking : null, draft)
  const hosts = messages.filter(message => message.agentId === 'host')
  return <div className="timeline-view"><p className="message-mark-hint">选中发言中的文字，可选择高亮、打点或加粗。</p><ol>{entries.map(message => {
    const agent = agents.find(a => a.id === message.agentId)
    const live = message.id === 'live-draft'
    return <li key={message.id}><div className="timeline-avatar">{agent ? <AgentAvatar agent={agent} /> : <span className="host-avatar"><UserRound className="size-5" /></span>}</div><article><header><strong>{agent?.name ?? `主持人介入 #${hosts.indexOf(message) + 1}`}</strong><span>{agent?.subtitle ?? '全员必读 · 优先回应'}</span><Badge variant="outline">{messageLabel(message)}{live ? ' · 正在接话' : ''}</Badge></header>{agent && entries.indexOf(message) > 0 && <div className="reply-label"><CornerDownRight className="size-3" />综合前文</div>}{agent && <ReadStatus message={message} messages={messages} />}{agent ? <MessageText content={message.content || '正在生成发言…'} marks={message.marks} messageId={!live ? message.id : undefined} onMark={!live ? mark => onMark(message.id, mark) : undefined} /> : <MessageText content={message.content || '正在生成发言…'} />}<RecordedInsights messageId={message.id} notes={notes} />{agent && !live && <Button variant="ghost" size="sm" onClick={() => onRecord(message)}><MessageSquare data-icon="inline-start" />记小结</Button>}</article></li>
  })}</ol>{!entries.length && <div className="empty-discussion"><MessageSquare className="size-9" /><h3>让想法开始碰撞</h3><p>设置议题与角色，点击「开始讨论」。</p></div>}</div>
}
export function SummaryView({ topic, messages, agents, preview, summary: generatedSummary, loading, error, onGenerate, canGenerate, onMark }: { topic: string; messages: Message[]; agents: Agent[]; preview: boolean; summary: string; loading: boolean; error: string; onGenerate: () => void; canGenerate: boolean; onMark: (messageId: string, mark: MessageMark) => void }) {
  const summary = createSummary(topic, messages, agents)
  return <div className="summary-view"><div className="summary-heading"><span className="summary-icon"><Sparkles /></span><div><h2>把不同视角，汇成下一步</h2><p>{preview ? '基于示例讨论的演示摘要' : `基于当前 ${summary.count} 条角色发言 · 观点摘录与模型总结`}</p></div>{!preview && <Button className="ml-auto" onClick={onGenerate} disabled={loading || !canGenerate}><Sparkles data-icon="inline-start" />{loading ? '正在生成总结…' : generatedSummary ? '重新生成总结' : '生成蓝帽总结'}</Button>}</div>{error && <div className="host-note" role="alert">{error}</div>}{(generatedSummary || loading) && <Card><CardHeader><CardTitle>蓝帽综合总结</CardTitle><CardDescription>step-5-preview · {loading ? '正在生成，完成后可导出' : '基于实际讨论记录生成'}</CardDescription></CardHeader><CardContent><MessageText content={generatedSummary || '模型正在分析讨论记录…'} /></CardContent></Card>}<Card><CardHeader><CardTitle>讨论议题</CardTitle><CardDescription>本次推演的起点</CardDescription></CardHeader><CardContent><p>{topic}</p></CardContent></Card><div className="summary-grid">{summary.contributions.map(({ agent, message }) => <Card key={agent.id}><CardHeader><CardTitle><span className="flex items-center gap-2"><AgentAvatar agent={agent} small />{agent.focus}</span></CardTitle><CardDescription>{agent.name} · 最新观点</CardDescription></CardHeader><CardContent><MessageText content={message!.content} marks={message!.marks} messageId={message!.id} onMark={mark => onMark(message!.id, mark)} /></CardContent></Card>)}</div>{summary.host && <Card><CardHeader><CardTitle>主持人关注点</CardTitle><CardDescription>接下来需要进一步验证的方向</CardDescription></CardHeader><CardContent>{summary.host.content}</CardContent></Card>}<Card><CardHeader><CardTitle>通用研究检查清单</CardTitle><CardDescription>此清单为预设建议；具体行动请以模型总结和真实验证为准。</CardDescription></CardHeader><CardContent><ol className="action-list"><li><span>01</span>核验各角色提出的关键假设与数据。</li><li><span>02</span>招募真实目标用户，开展问题访谈。</li><li><span>03</span>制作轻量原型，用行为指标验证核心场景。</li></ol></CardContent></Card></div>
}
