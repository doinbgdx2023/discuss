'use client'

import { useState } from 'react'
import { RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Textarea } from '@/components/ui/textarea'
import { hats, meetingVoice, type Agent } from '@/lib/discussion'

export function HatPromptEditor({ agent, onClose, onSave }: { agent: Agent; onClose: () => void; onSave: (prompt: string) => void }) {
  const [prompt, setPrompt] = useState(agent.prompt)
  const original = hats.find(item => item.id === agent.id)!.prompt

  return <Dialog open onOpenChange={open => { if (!open) onClose() }}>
    <DialogContent className="workspace-dialog max-h-[85dvh] overflow-y-auto sm:max-w-2xl">
      <DialogHeader>
        <DialogTitle>{agent.name} · 人设提示词</DialogTitle>
        <DialogDescription>决定这位同事关注什么、什么脾气、怎么说话。应用后，下次开始讨论时生效；刷新页面会恢复默认。</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="hat-prompt">性格、立场与说话方式</FieldLabel>
          <Textarea id="hat-prompt" rows={8} maxLength={1000} value={prompt} onChange={event => setPrompt(event.target.value)} className="min-h-48" aria-describedby="hat-prompt-help" />
          <FieldDescription id="hat-prompt-help">可以写：说话直一点、少客套、敢反驳，只盯一个具体问题。{prompt.length}/1000 字</FieldDescription>
        </Field>
        <details className="rounded-lg border p-3 text-sm">
          <summary className="cursor-pointer">查看共同发言规则（所有角色生效）</summary>
          <p className="mt-3 leading-relaxed text-muted-foreground">{meetingVoice}</p>
        </details>
      </FieldGroup>
      <DialogFooter className="flex-wrap gap-2">
        <Button variant="ghost" onClick={() => setPrompt(original)}><RotateCcw data-icon="inline-start" />恢复默认人设</Button>
        <Button variant="outline" onClick={onClose}>取消</Button>
        <Button disabled={!prompt.trim()} onClick={() => onSave(prompt.trim())}>应用人设</Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
}
